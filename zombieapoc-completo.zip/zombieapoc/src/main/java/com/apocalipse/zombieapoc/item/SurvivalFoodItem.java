package com.apocalipse.zombieapoc.item;

import com.apocalipse.zombieapoc.capability.ModCapabilities;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Comida "normal" (usa o sistema de fome vanilla via FoodProperties),
 * mas com um extra opcional: restaurar um pouco de SEDE tambem (ex:
 * o MRE militar inclui liquido). Deixe thirstRestore = 0 pra comidas
 * que nao devem mexer na sede.
 */
public class SurvivalFoodItem extends Item {

    private final float thirstRestore;
    private final int useDurationOverride;

    public SurvivalFoodItem(float thirstRestore, Properties properties) {
        this(thirstRestore, -1, properties);
    }

    public SurvivalFoodItem(float thirstRestore, int useDurationOverride, Properties properties) {
        super(properties);
        this.thirstRestore = thirstRestore;
        this.useDurationOverride = useDurationOverride;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return useDurationOverride >= 0 ? useDurationOverride : super.getUseDuration(stack);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack resultado = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide && thirstRestore > 0.0F && entity instanceof Player player) {
            player.getCapability(ModCapabilities.THIRST).ifPresent(sede -> sede.addThirst(thirstRestore));
        }
        return resultado;
    }
}
