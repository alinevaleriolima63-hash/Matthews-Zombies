package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.entity.ApocalypseZombieEntity;
import com.apocalipse.zombieapoc.entity.GrenadeEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registro dos EntityType do mod. Hoje existe apenas um EntityType
 * (ApocalypseZombieEntity), que representa os 5 tipos de zumbi via
 * o campo `variant` (ver ZombieVariant.java). Isso evita registrar
 * 5 EntityTypes quase identicos.
 */
public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ZombieApocMod.MOD_ID);

    public static final RegistryObject<EntityType<ApocalypseZombieEntity>> APOCALYPSE_ZOMBIE =
            ENTITY_TYPES.register("apocalypse_zombie", () -> EntityType.Builder
                    .of(ApocalypseZombieEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(8)
                    .build(new ResourceLocation(ZombieApocMod.MOD_ID, "apocalypse_zombie").toString()));

    public static final RegistryObject<EntityType<GrenadeEntity>> GRENADE =
            ENTITY_TYPES.register("grenade", () -> EntityType.Builder
                    .<GrenadeEntity>of(GrenadeEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new ResourceLocation(ZombieApocMod.MOD_ID, "grenade").toString()));
}
