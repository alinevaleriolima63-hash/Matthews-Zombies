package com.apocalipse.zombieapoc.entity;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraft.resources.ResourceLocation;

/**
 * Define os 5 tipos de zumbi e seus atributos individuais.
 * Usar um enum de dados (em vez de 5 classes Java separadas) evita
 * codigo duplicado: toda a logica de IA/atributos fica em
 * ApocalypseZombieEntity, e este enum so guarda os NUMEROS que
 * diferenciam cada variante. Isso reduz superficie de bugs.
 *
 * Ordinal e usado para sincronizar o valor pela SynchedEntityData
 * (cliente/servidor), entao a ORDEM dos valores abaixo nao deve
 * mudar depois que o mod for lancado (senao mundos salvos quebram).
 */
public enum ZombieVariant {

    // nome         vida   veloc. attr  velocMov  dano   escala  chanceDropParte  pesoSpawn
    NORMAL("normal", 20.0D, 0.23D, 3.0D, 1.0F, 0.15F, 8),
    ARMADO("armado", 24.0D, 0.24D, 5.0D, 1.0F, 0.25F, 6),
    QUEIMADO("queimado", 18.0D, 0.27D, 4.0D, 1.0F, 0.20F, 5),
    MUTANTE("mutante", 55.0D, 0.30D, 8.0D, 1.6F, 0.35F, 3),
    NECROMANTE("necromante", 26.0D, 0.20D, 2.0D, 1.0F, 0.30F, 2);

    private final String id;
    private final double maxHealth;
    private final double movementSpeed;
    private final double attackDamage;
    private final float scale;
    private final float partDropChance;
    private final int spawnWeight;

    ZombieVariant(String id, double maxHealth, double movementSpeed, double attackDamage,
                  float scale, float partDropChance, int spawnWeight) {
        this.id = id;
        this.maxHealth = maxHealth;
        this.movementSpeed = movementSpeed;
        this.attackDamage = attackDamage;
        this.scale = scale;
        this.partDropChance = partDropChance;
        this.spawnWeight = spawnWeight;
    }

    public String getId() {
        return id;
    }

    public double getMaxHealth() {
        return maxHealth;
    }

    public double getMovementSpeed() {
        return movementSpeed;
    }

    public double getAttackDamage() {
        return attackDamage;
    }

    public float getScale() {
        return scale;
    }

    public float getPartDropChance() {
        return partDropChance;
    }

    public int getSpawnWeight() {
        return spawnWeight;
    }

    public ResourceLocation getTexture() {
        return new ResourceLocation(ZombieApocMod.MOD_ID, "textures/entity/zombie/" + id + ".png");
    }

    public ResourceLocation getTextureNoturna() {
        return new ResourceLocation(ZombieApocMod.MOD_ID, "textures/entity/zombie/" + id + "_noite.png");
    }

    public ResourceLocation getLootTable() {
        return new ResourceLocation(ZombieApocMod.MOD_ID, "entities/zumbi_" + id);
    }

    public static ZombieVariant byId(int ordinal) {
        ZombieVariant[] values = values();
        if (ordinal < 0 || ordinal >= values.length) {
            return NORMAL;
        }
        return values[ordinal];
    }
}
