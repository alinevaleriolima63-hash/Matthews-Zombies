package com.apocalipse.zombieapoc.entity;

import com.apocalipse.zombieapoc.registry.ModEntities;
import com.apocalipse.zombieapoc.registry.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Projetil da granada. Explode ao acertar algo, ou apos um pavio
 * maximo de 3 segundos (evita granada "perdida" voando pra sempre).
 */
public class GrenadeEntity extends ThrowableItemProjectile {

    private static final int PAVIO_MAXIMO_TICKS = 60;

    public GrenadeEntity(EntityType<? extends GrenadeEntity> type, Level level) {
        super(type, level);
    }

    public GrenadeEntity(Level level, LivingEntity arremessador) {
        super(ModEntities.GRENADE.get(), arremessador, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.GRANADA.get();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        explodir();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        explodir();
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount >= PAVIO_MAXIMO_TICKS) {
            explodir();
        }
    }

    private void explodir() {
        if (this.level().isClientSide || this.isRemoved()) {
            return;
        }
        // Se "ExplosionInteraction" nao existir na sua build do Forge,
        // troque essa linha pela assinatura usada por PrimedTnt.explode().
        this.level().explode(this, this.getX(), this.getY(), this.getZ(), 2.5F, false,
                Level.ExplosionInteraction.MOB);
        this.discard();
    }
}
