package com.apocalipse.zombieapoc.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.ServerLevelAccessor;
import javax.annotation.Nullable;

/**
 * Entidade unica que representa os 5 tipos de zumbi do mod
 * (NORMAL, ARMADO, QUEIMADO, MUTANTE, NECROMANTE), diferenciados
 * pelo campo `variant`. Estende Zombie para reaproveitar toda a
 * IA vanilla (perseguir jogador, quebrar portas, queimar no sol,
 * virar afogado na agua, etc.) e so sobrescreve o que realmente
 * muda por variante.
 */
public class ApocalypseZombieEntity extends Zombie {

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(ApocalypseZombieEntity.class, EntityDataSerializers.INT);

    private static final java.util.UUID BONUS_VELOCIDADE_NOTURNO_ID =
            java.util.UUID.fromString("8c56f3a1-9999-4a2e-9e2b-000000000099");

    private boolean bonusNoturnoAtivo = false;

    public ApocalypseZombieEntity(EntityType<? extends Zombie> type, net.minecraft.world.level.Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(2, new NecromanteAbilityGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // A cada 20 ticks (1s), nao every tick - checagem barata o
        // suficiente pra nao precisar de mais que isso.
        if (!this.level().isClientSide && this.tickCount % 20 == 0) {
            atualizarBonusVelocidadeNoturna();
        }
    }

    private void atualizarBonusVelocidadeNoturna() {
        boolean noite = ApocalypseTimeUtil.ehNoite(this.level());
        if (noite == bonusNoturnoAtivo) {
            return;
        }
        bonusNoturnoAtivo = noite;

        net.minecraft.world.entity.ai.attributes.AttributeInstance velocidade =
                this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (velocidade == null) {
            return;
        }
        velocidade.removeModifier(BONUS_VELOCIDADE_NOTURNO_ID);
        if (noite) {
            velocidade.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(
                    BONUS_VELOCIDADE_NOTURNO_ID, "Bonus noturno", 0.35D,
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        // Ranges genericos dos atributos vanilla ja cobrem os valores
        // usados por todas as variantes (ate 55 de vida, 8 de dano).
        return Zombie.createAttributes();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, ZombieVariant.NORMAL.ordinal());
    }

    public ZombieVariant getVariant() {
        return ZombieVariant.byId(this.entityData.get(DATA_VARIANT));
    }

    public void setVariant(ZombieVariant variant) {
        this.entityData.set(DATA_VARIANT, variant.ordinal());
        applyVariantAttributes(variant);
    }

    private void applyVariantAttributes(ZombieVariant variant) {
        this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)
                .setBaseValue(variant.getMaxHealth());
        this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                .setBaseValue(variant.getMovementSpeed());
        this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)
                .setBaseValue(variant.getAttackDamage());
        // So restaura a vida cheia se a entidade acabou de nascer
        // (evita curar um zumbi que ja levou dano ao trocar de variante).
        if (this.tickCount == 0) {
            this.setHealth(this.getMaxHealth());
        }
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                         MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData,
                                         @Nullable CompoundTag tag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, tag);
        if (tag == null || !tag.contains("ZombieApocVariant")) {
            setVariant(pickRandomVariant(this.random));
        }
        return data;
    }

    private static ZombieVariant pickRandomVariant(RandomSource random) {
        ZombieVariant[] variantes = ZombieVariant.values();
        int pesoTotal = 0;
        for (ZombieVariant v : variantes) {
            pesoTotal += v.getSpawnWeight();
        }
        int alvo = random.nextInt(pesoTotal);
        for (ZombieVariant v : variantes) {
            alvo -= v.getSpawnWeight();
            if (alvo  {
                if (target instanceof LivingEntity living) {
                    living.setSecondsOnFire(6);
                }
            }
            case MUTANTE -> {
                if (target instanceof LivingEntity living) {
                    double dx = target.getX() - this.getX();
                    double dz = target.getZ() - this.getZ();
                    living.knockback(1.2D, -dx, -dz);
                }
            }
            default -> {
                // NORMAL, ARMADO e NECROMANTE nao tem efeito extra no golpe.
            }
        }
        return true;
    }

    @Override
    public boolean fireImmune() {
        // Zumbi queimado e imune a fogo (sol, lava, etc) - ja "aceitou" o fogo.
        return getVariant() == ZombieVariant.QUEIMADO || super.fireImmune();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        float escala = getVariant().getScale();
        return super.getDimensions(pose).scale(escala);
    }

    @Override
    protected ResourceLocation getLootTableLocation() {
        return getVariant().getLootTable();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ZombieApocVariant", getVariant().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("ZombieApocVariant")) {
            setVariant(ZombieVariant.byId(tag.getInt("ZombieApocVariant")));
        }
    }
}
ditionalSaveData(tag);
        tag.putInt("ZombieApocVariant", getVariant().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("ZombieApocVariant")) {
            setVariant(ZombieVariant.byId(tag.getInt("ZombieApocVariant")));
        }
    }
}
