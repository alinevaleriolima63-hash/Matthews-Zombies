package com.apocalipse.zombieapoc.entity;

import com.apocalipse.zombieapoc.registry.ModEntities;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.List;

/**
 * Habilidade do zumbi necromante: a cada X segundos, ou invoca 1-2
 * zumbis comuns por perto, ou amaldicoa jogadores proximos com
 * fraqueza/nausea. So funciona quando a variante da entidade e
 * NECROMANTE (verificado em canUse), entao e seguro registrar este
 * goal em TODOS os ApocalypseZombieEntity sem checar a variante
 * antes de adicionar o goal.
 */
public class NecromanteAbilityGoal extends Goal {

    private static final int COOLDOWN_MIN = 140; // ~7s
    private static final int COOLDOWN_MAX = 260; // ~13s
    private static final int MAX_ZUMBIS_PROXIMOS = 5;
    private static final double RAIO_HABILIDADE = 10.0D;

    private final ApocalypseZombieEntity necromante;
    private int cooldown;

    public NecromanteAbilityGoal(ApocalypseZombieEntity necromante) {
        this.necromante = necromante;
        this.cooldown = randomCooldown(necromante.getRandom());
        this.setFlags(EnumSet.noneOf(Goal.Flag.class));
    }

    @Override
    public boolean canUse() {
        return necromante.getVariant() == ZombieVariant.NECROMANTE && necromante.isAlive();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        cooldown = randomCooldown(necromante.getRandom());

        if (necromante.getRandom().nextBoolean()) {
            tentarInvocarZumbis();
        } else {
            amaldicoarJogadoresProximos();
        }
    }

    private void tentarInvocarZumbis() {
        if (necromante.level().isClientSide) {
            return;
        }
        AABB area = necromante.getBoundingBox().inflate(RAIO_HABILIDADE);
        List<ApocalypseZombieEntity> zumbisProximos =
                necromante.level().getEntitiesOfClass(ApocalypseZombieEntity.class, area);
        if (zumbisProximos.size() >= MAX_ZUMBIS_PROXIMOS) {
            return;
        }

        int quantidade = 1 + necromante.getRandom().nextInt(2);
        for (int i = 0; i < quantidade; i++) {
            ApocalypseZombieEntity invocado = ModEntities.APOCALYPSE_ZOMBIE.get().create(necromante.level());
            if (invocado == null) {
                continue;
            }
            double angulo = necromante.getRandom().nextDouble() * Math.PI * 2;
            double x = necromante.getX() + Math.cos(angulo) * 2.5D;
            double z = necromante.getZ() + Math.sin(angulo) * 2.5D;
            invocado.moveTo(x, necromante.getY(), z, necromante.getRandom().nextFloat() * 360.0F, 0.0F);
            invocado.finalizeSpawn((net.minecraft.server.level.ServerLevel) necromante.level(),
                    necromante.level().getCurrentDifficultyAt(invocado.blockPosition()),
                    net.minecraft.world.entity.MobSpawnType.MOB_SUMMONED, null, null);
            invocado.setVariant(ZombieVariant.NORMAL);
            necromante.level().addFreshEntity(invocado);
        }
    }

    private void amaldicoarJogadoresProximos() {
        AABB area = necromante.getBoundingBox().inflate(RAIO_HABILIDADE);
        List<Player> jogadores = necromante.level().getEntitiesOfClass(Player.class, area);
        for (Player jogador : jogadores) {
            jogador.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 140, 0));
            jogador.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
        }
    }

    private static int randomCooldown(RandomSource random) {
        return COOLDOWN_MIN + random.nextInt(COOLDOWN_MAX - COOLDOWN_MIN);
    }
}
