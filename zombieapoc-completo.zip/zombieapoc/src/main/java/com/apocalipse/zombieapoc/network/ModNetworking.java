package com.apocalipse.zombieapoc.network;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * Canal de rede unico do mod. Cada pacote novo (proximos modulos
 * tambem podem usar) se registra aqui com um ID sequencial.
 */
public class ModNetworking {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ZombieApocMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int proximoId = 0;

    public static void register() {
        CHANNEL.registerMessage(proximoId++, ThirstSyncPacket.class,
                ThirstSyncPacket::encode, ThirstSyncPacket::decode, ThirstSyncPacket::handle);
    }
}
