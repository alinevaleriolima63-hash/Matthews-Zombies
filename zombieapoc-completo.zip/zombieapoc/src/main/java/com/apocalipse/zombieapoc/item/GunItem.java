package com.apocalipse.zombieapoc.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Supplier;

/**
 * Arma de fogo generica (hitscan, sem entidade de projetil fisica -
 * escolha deliberada pra reduzir superficie de bug/latencia de rede
 * comparado a uma entidade "bala" com fisica propria).
 *
 * Sistema de carregador via NBT do ItemStack:
 *  - clique normal com o botao direito = atirar (consome 1 do
 *    carregador atual, guardado na propria ItemStack)
 *  - agachado + botao direito = recarregar (consome municao do
 *    inventario e enche o carregador ate o maximo)
 */
public class GunItem extends Item {

    private static final String TAG_CARREGADOR = "CarregadorAtual";

    private final Supplier<? extends Item> municaoItem;
    private final int tamanhoCarregador;
    private final float danoPorTiro;
    private final int pellets;
    private final float espalhamentoGraus;
    private final double alcance;
    private final int cooldownTicks;
    private final Supplier<SoundEvent> somTiro;

    public GunItem(Supplier<? extends Item> municaoItem, int tamanhoCarregador, float danoPorTiro, int pellets,
                   float espalhamentoGraus, double alcance, int cooldownTicks,
                   Supplier<SoundEvent> somTiro, Properties properties) {
        super(properties);
        this.municaoItem = municaoItem;
        this.tamanhoCarregador = tamanhoCarregador;
        this.danoPorTiro = danoPorTiro;
        this.pellets = pellets;
        this.espalhamentoGraus = espalhamentoGraus;
        this.alcance = alcance;
        this.cooldownTicks = cooldownTicks;
        this.somTiro = somTiro;
    }

    public int getCarregado(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null ? tag.getInt(TAG_CARREGADOR) : 0;
    }

    private void setCarregado(ItemStack stack, int valor) {
        stack.getOrCreateTag().putInt(TAG_CARREGADOR, valor);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResultHolder.pass(stack);
        }

        if (player.isShiftKeyDown()) {
            recarregar(stack, player, level);
            return InteractionResultHolder.consume(stack);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        int carregado = getCarregado(stack);
        if (carregado <= 0) {
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            player.getCooldowns().addCooldown(this, 5);
            return InteractionResultHolder.fail(stack);
        }

        if (!level.isClientSide) {
            atirar(level, player);
            setCarregado(stack, carregado - 1);
        }
        player.getCooldowns().addCooldown(this, cooldownTicks);
        level.playSound(null, player.blockPosition(), somTiro.get(), SoundSource.PLAYERS, 1.0F,
                1.0F + (level.random.nextFloat() - 0.5F) * 0.2F);
        return InteractionResultHolder.consume(stack);
    }

    private void recarregar(ItemStack stack, Player player, Level level) {
        int carregado = getCarregado(stack);
        int faltando = tamanhoCarregador - carregado;
        if (faltando <= 0) {
            return;
        }

        if (player.getAbilities().instabuild) {
            setCarregado(stack, tamanhoCarregador);
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_IRON,
                    SoundSource.PLAYERS, 0.8F, 1.2F);
            return;
        }

        Item municao = municaoItem.get();
        int disponivel = contarMunicao(player, municao);
        int aRecarregar = Math.min(faltando, disponivel);
        if (aRecarregar <= 0) {
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            return;
        }

        consumirMunicao(player, municao, aRecarregar);
        setCarregado(stack, carregado + aRecarregar);
        level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_IRON,
                SoundSource.PLAYERS, 0.8F, 1.2F);
    }

    private int contarMunicao(Player player, Item municao) {
        int total = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(municao)) {
                total += stack.getCount();
            }
        }
        return total;
    }

    private void consumirMunicao(Player player, Item municao, int quantidade) {
        int restante = quantidade;
        for (ItemStack stack : player.getInventory().items) {
            if (restante <= 0) {
                break;
            }
            if (stack.is(municao)) {
                int retirar = Math.min(restante, stack.getCount());
                stack.shrink(retirar);
                restante -= retirar;
            }
        }
    }

    private void atirar(Level level, Player player) {
        Vec3 origem = player.getEyePosition(1.0F);
        Vec3 direcaoBase = player.getViewVector(1.0F);
        RandomSource random = level.random;

        for (int i = 0; i < pellets; i++) {
            Vec3 direcao = aplicarEspalhamento(direcaoBase, random, espalhamentoGraus);
            Vec3 destino = origem.add(direcao.scale(alcance));

            ClipContext clipContext = new ClipContext(origem, destino, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player);
            BlockHitResult blockHit = level.clip(clipContext);
            Vec3 fimReal = blockHit.getType() != HitResult.Type.MISS ? blockHit.getLocation() : destino;

            AABB caixaBusca = player.getBoundingBox().expandTowards(direcao.scale(alcance)).inflate(1.0D);
            // NOTA: se essa chamada nao compilar na sua versao exata do
            // Forge, compare a assinatura com a usada por AbstractArrow
            // (arco/besta vanilla) no metodo findHitEntity().
            EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(level, player, origem, fimReal,
                    caixaBusca, this::podeAtingir);

            if (entityHit != null) {
                Entity alvo = entityHit.getEntity();
                DamageSource fonte = player.damageSources().playerAttack(player);
                alvo.hurt(fonte, danoPorTiro);
                if (alvo instanceof LivingEntity living) {
                    double dx = alvo.getX() - player.getX();
                    double dz = alvo.getZ() - player.getZ();
                    living.knockback(0.3D, -dx, -dz);
                }
                fimReal = entityHit.getLocation();
            }

            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.CRIT, fimReal.x, fimReal.y, fimReal.z, 3,
                        0.05, 0.05, 0.05, 0.01);
            }
        }
    }

    private boolean podeAtingir(Entity entidade) {
        return !entidade.isSpectator() && entidade.isPickable() && !(entidade instanceof TamableAnimal tamable
                && tamable.isTame());
    }

    private static Vec3 aplicarEspalhamento(Vec3 direcao, RandomSource random, float grausMax) {
        if (grausMax <= 0.0F) {
            return direcao;
        }
        float anguloY = (random.nextFloat() - 0.5F) * grausMax;
        float anguloX = (random.nextFloat() - 0.5F) * grausMax;
        return direcao.yRot((float) Math.toRadians(anguloY)).xRot((float) Math.toRadians(anguloX));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("item.zombieapoc.gun.ammo", getCarregado(stack), tamanhoCarregador)
                .withStyle(net.minecraft.ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.zombieapoc.gun.reload_hint")
                .withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
    }
}
