package com.apocalipse.zombieapoc.capability;

/**
 * Contrato da "sede" de um jogador. Implementacao real em Thirst.java.
 * Interface separada da implementacao e o padrao exigido pelo sistema
 * de Capability do Forge.
 */
public interface IThirst {

    float getThirst();

    void setThirst(float value);

    void addThirst(float amount);

    float getMaxThirst();
}
