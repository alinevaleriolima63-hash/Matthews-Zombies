package com.apocalipse.zombieapoc.client;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.network.ClientThirstData;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Barra de sede (gotas azuis), desenhada acima da barra de fome.
 *
 * NOTA: "RegisterGuiOverlaysEvent" e a API de overlays do Forge pra
 * 1.20.1. Se o metodo registerAboveAll no final deste arquivo nao
 * existir na sua build exata, procure na mesma classe por
 * registerAbove/registerBelow (a ideia e a mesma, so muda onde a
 * barra aparece em relacao as outras).
 */
@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ThirstHudOverlay {

    private static final ResourceLocation TEXTURA_CHEIA =
            new ResourceLocation(ZombieApocMod.MOD_ID, "textures/gui/thirst_full.png");
    private static final ResourceLocation TEXTURA_VAZIA =
            new ResourceLocation(ZombieApocMod.MOD_ID, "textures/gui/thirst_empty.png");

    public static final IGuiOverlay HUD_SEDE = ThirstHudOverlay::render;

    private static void render(net.minecraftforge.client.gui.overlay.ForgeGui gui, GuiGraphics guiGraphics,
                                float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) {
            return;
        }
        if (mc.gameMode != null && mc.gameMode.getPlayerMode().isCreative()) {
            return;
        }

        float sede = ClientThirstData.getThirst();
        int cheios = (int) Math.ceil(sede / 2.0F);

        int x = width / 2 + 91; // simetrico a barra de fome vanilla (lado direito)
        int y = height - 39;
        // Se a barra de armadura estiver visivel isso pode sobrepor;
        // ajuste "y" se notar sobreposicao no seu HUD.

        RenderSystem.enableBlend();
        for (int i = 0; i < 10; i++) {
            int posX = x - i * 8 - 9;
            ResourceLocation textura = i < cheios ? TEXTURA_CHEIA : TEXTURA_VAZIA;
            guiGraphics.blit(textura, posX, y, 0, 0, 9, 9, 9, 9);
        }
        RenderSystem.disableBlend();
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("thirst_hud", HUD_SEDE);
    }
}
