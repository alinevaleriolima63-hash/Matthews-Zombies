package com.apocalipse.zombieapoc.item;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Motosserra: alem do dano normal no alvo principal, acerta tambem
 * outros mobs proximos (efeito "cleave"), simulando a lamina girando.
 * O dano de "respingo" nos alvos secundarios e menor que o principal.
 */
public class ChainsawItem extends MeleeWeaponItem {

    private static final double RAIO_CLEAVE = 2.5D;
    private final float danoCleave;

    public ChainsawItem(Tier tier, float attackDamage, float attackSpeed, float danoCleave, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
        this.danoCleave = danoCleave;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean resultado = super.hurtEnemy(stack, target, attacker);
        if (!resultado || attacker.level().isClientSide) {
            return resultado;
        }

        AABB area = target.getBoundingBox().inflate(RAIO_CLEAVE);
        List<LivingEntity> proximos = attacker.level().getEntitiesOfClass(LivingEntity.class, area,
                entidade -> entidade != target && entidade != attacker && entidade.isAlive());

        DamageSource fonte = attacker.damageSources().mobAttack(attacker);
        for (LivingEntity secundario : proximos) {
            secundario.hurt(fonte, danoCleave);
        }
        return resultado;
    }
}
