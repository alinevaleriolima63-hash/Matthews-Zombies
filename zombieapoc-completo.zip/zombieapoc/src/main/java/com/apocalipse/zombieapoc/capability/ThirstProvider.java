package com.apocalipse.zombieapoc.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class ThirstProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {

    private final Thirst thirst = new Thirst();
    private final LazyOptional<IThirst> optional = LazyOptional.of(() -> thirst);

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == ModCapabilities.THIRST ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return thirst.serializeNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        thirst.deserializeNBT(nbt);
    }

    public void invalidate() {
        optional.invalidate();
    }
}
