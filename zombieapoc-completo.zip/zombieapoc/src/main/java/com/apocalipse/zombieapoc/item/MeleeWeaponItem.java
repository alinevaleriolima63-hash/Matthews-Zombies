package com.apocalipse.zombieapoc.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

import java.util.UUID;

/**
 * Base para armas corpo a corpo "estilo espada" (faca, katana, bastao,
 * taco, marreta). Em vez de usar o dano/velocidade calculados a partir
 * do Tier (formula fixa da Mojang), sobrescrevemos
 * getDefaultAttributeModifiers e definimos o dano/velocidade EXATOS
 * de cada arma diretamente - assim cada item tem valores proprios e
 * previsiveis, sem depender de formula escondida do tier vanilla.
 *
 * O Tier passado no construtor so afeta durabilidade base/nivel de
 * mineracao/encantabilidade/material de reparo - a durabilidade real
 * de uso e sempre sobrescrita via Item.Properties().durability(int).
 */
public class MeleeWeaponItem extends SwordItem {

    private static final UUID ATTACK_DAMAGE_UUID = UUID.fromString("8c56f3a1-1111-4a2e-9e2b-000000000001");
    private static final UUID ATTACK_SPEED_UUID = UUID.fromString("8c56f3a1-1111-4a2e-9e2b-000000000002");

    private final float attackDamage;
    private final float attackSpeed;
    private final float bonusKnockback;

    public MeleeWeaponItem(Tier tier, float attackDamage, float attackSpeed, Properties properties) {
        this(tier, attackDamage, attackSpeed, 0.0F, properties);
    }

    public MeleeWeaponItem(Tier tier, float attackDamage, float attackSpeed, float bonusKnockback,
                            Properties properties) {
        // O 0 e -2.4F passados aqui pro super() sao ignorados na pratica,
        // pois getDefaultAttributeModifiers() e sobrescrito abaixo.
        super(tier, 0, -2.4F, properties);
        this.attackDamage = attackDamage;
        this.attackSpeed = attackSpeed;
        this.bonusKnockback = bonusKnockback;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot == EquipmentSlot.MAINHAND) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(
                    ATTACK_DAMAGE_UUID, "Weapon modifier", attackDamage, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(
                    ATTACK_SPEED_UUID, "Weapon modifier", attackSpeed, AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean resultado = super.hurtEnemy(stack, target, attacker);
        if (bonusKnockback > 0.0F && resultado) {
            double dx = target.getX() - attacker.getX();
            double dz = target.getZ() - attacker.getZ();
            target.knockback(bonusKnockback, -dx, -dz);
        }
        return resultado;
    }
}
