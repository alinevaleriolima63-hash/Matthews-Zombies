package com.apocalipse.zombieapoc.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Carcaca baixa de veiculo abandonado com 1 bau de loot. Forma
 * simplificada (nao e um modelo 3D de carro de verdade, so um bloco
 * baixo reconhecivel como "destroços") - deixei isso claro no README.
 */
public class WreckedVehicleFeature extends Feature<NoneFeatureConfiguration> {

    private final ResourceLocation lootTable;

    public WreckedVehicleFeature(ResourceLocation lootTable) {
        super(NoneFeatureConfiguration.CODEC);
        this.lootTable = lootTable;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        RandomSource random = context.random();
        BlockPos origem = context.origin();

        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, origem.getX(), origem.getZ());
        BlockPos base = new BlockPos(origem.getX(), y, origem.getZ());

        if (level.getFluidState(base).is(FluidTags.WATER) || level.getFluidState(base).is(FluidTags.LAVA)) {
            return false;
        }

        Block corpo = random.nextBoolean() ? Blocks.IRON_BLOCK : Blocks.COAL_BLOCK;
        for (int x = 0; x < 4; x++) {
            for (int z = 0; z < 2; z++) {
                level.setBlock(base.offset(x, 0, z), corpo.defaultBlockState(), 3);
            }
        }
        for (int x = 0; x < 4; x++) {
            if (random.nextFloat() < 0.6F) {
                level.setBlock(base.offset(x, 1, 0), Blocks.IRON_BARS.defaultBlockState(), 3);
            }
        }
        for (int i = 0; i < 4; i++) {
            int dx = -1 + random.nextInt(6);
            int dz = -1 + random.nextInt(4);
            if (random.nextFloat() < 0.5F) {
                level.setBlock(base.offset(dx, 0, dz), Blocks.GRAVEL.defaultBlockState(), 3);
            }
        }

        BlockPos posBau = base.offset(3, 0, 0);
        level.setBlock(posBau, Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity blockEntity = level.getBlockEntity(posBau);
        if (blockEntity instanceof RandomizableContainerBlockEntity container) {
            container.setLootTable(lootTable, random.nextLong());
        }

        return true;
    }
}
