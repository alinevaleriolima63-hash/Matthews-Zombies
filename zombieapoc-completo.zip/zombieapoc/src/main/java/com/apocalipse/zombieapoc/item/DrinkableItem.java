package com.apocalipse.zombieapoc.item;

import com.apocalipse.zombieapoc.capability.ModCapabilities;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Item de agua: acao de "beber" propria (nao usa FoodProperties,
 * porque nao deve mexer na fome, so na sede). Agua contaminada tem
 * chance de deixar o jogador doente - o incentivo pra filtrar.
 */
public class DrinkableItem extends Item {

    private final float thirstRestore;
    @Nullable
    private final MobEffectInstance efeitoNegativo;
    private final float chanceEfeitoNegativo;

    public DrinkableItem(float thirstRestore, Properties properties) {
        this(thirstRestore, null, 0.0F, properties);
    }

    public DrinkableItem(float thirstRestore, @Nullable MobEffectInstance efeitoNegativo,
                          float chanceEfeitoNegativo, Properties properties) {
        super(properties);
        this.thirstRestore = thirstRestore;
        this.efeitoNegativo = efeitoNegativo;
        this.chanceEfeitoNegativo = chanceEfeitoNegativo;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 24;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player) {
            player.getCapability(ModCapabilities.THIRST).ifPresent(sede -> sede.addThirst(thirstRestore));
            if (efeitoNegativo != null && level.random.nextFloat() < chanceEfeitoNegativo) {
                player.addEffect(new MobEffectInstance(efeitoNegativo));
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.GENERIC_DRINK, SoundSource.PLAYERS, 1.0F, 1.0F);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return stack;
    }
}
