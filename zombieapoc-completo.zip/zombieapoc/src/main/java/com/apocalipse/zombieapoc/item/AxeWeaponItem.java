package com.apocalipse.zombieapoc.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Tier;

import java.util.UUID;

/**
 * Machado usavel tanto como arma (dano customizado) quanto como
 * ferramenta de verdade (continua cortando madeira, ja que estende
 * AxeItem em vez de reimplementar tudo do zero).
 */
public class AxeWeaponItem extends AxeItem {

    private static final UUID ATTACK_DAMAGE_UUID = UUID.fromString("8c56f3a1-2222-4a2e-9e2b-000000000001");
    private static final UUID ATTACK_SPEED_UUID = UUID.fromString("8c56f3a1-2222-4a2e-9e2b-000000000002");

    private final float attackDamage;
    private final float attackSpeed;

    public AxeWeaponItem(Tier tier, float attackDamage, float attackSpeed, Properties properties) {
        super(tier, 0.0F, -3.2F, properties);
        this.attackDamage = attackDamage;
        this.attackSpeed = attackSpeed;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot == EquipmentSlot.MAINHAND) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(
                    ATTACK_DAMAGE_UUID, "Weapon modifier", attackDamage, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(
                    ATTACK_SPEED_UUID, "Weapon modifier", attackSpeed, AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.getDefaultAttributeModifiers(slot);
    }
}
