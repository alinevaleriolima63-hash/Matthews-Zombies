package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraftforge.event.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Faz o item Combustivel funcionar em fornalhas (queima bastante,
 * representando um galao de gasolina). NOTA: se
 * "FurnaceFuelBurnTimeEvent" nao existir com esse nome exato na sua
 * build, procure por eventos com "FuelBurnTime" no pacote
 * net.minecraftforge.event - o nome variou entre versoes do Forge.
 */
@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID)
public class ModFuelHandler {

    private static final int TEMPO_QUEIMA_COMBUSTIVEL = 4000; // ~200s (coal vanilla = 1600)

    @SubscribeEvent
    public static void onFurnaceFuelBurnTime(FurnaceFuelBurnTimeEvent event) {
        if (event.getItemStack().is(ModItems.COMBUSTIVEL.get())) {
            event.setBurnTime(TEMPO_QUEIMA_COMBUSTIVEL);
        }
    }
}
