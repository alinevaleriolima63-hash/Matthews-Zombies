package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ModFuelHandler {
    private static final int QUEIMA = 4000;

    @SubscribeEvent
    public static void onFurnaceFuelBurnTime(FurnaceFuelBurnTimeEvent event) {
        ItemStack item = event.getItemStack();
        if (item != null && item.is(ModItems.COMBUSTIVEL.get())) {
            event.setBurnTime(QUEIMA);
        }
    }
}
rnTime(TEMPO_QUEIMA_COMBUSTIVEL);
        }
    }
}
onFurnaceFuelBurnTime(FurnaceFuelBurnTimeEvent event) {
        if (event.getItemStack().is(ModItems.COMBUSTIVEL.get())) {
            event.setBurnTime(TEMPO_QUEIMA_COMBUSTIVEL);
        }
    }
}
