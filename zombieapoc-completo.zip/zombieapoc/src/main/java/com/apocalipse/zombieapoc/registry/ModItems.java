package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.item.AxeWeaponItem;
import com.apocalipse.zombieapoc.item.ChainsawItem;
import com.apocalipse.zombieapoc.item.DrinkableItem;
import com.apocalipse.zombieapoc.item.GrenadeItem;
import com.apocalipse.zombieapoc.item.GunItem;
import com.apocalipse.zombieapoc.item.MedkitItem;
import com.apocalipse.zombieapoc.item.MeleeWeaponItem;
import com.apocalipse.zombieapoc.item.ShovelWeaponItem;
import com.apocalipse.zombieapoc.item.SurvivalFoodItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

/**
 * Registro central de todos os itens do mod.
 * Modulo 1: itens de zumbi (drops).
 * Modulo 2: municao + 8 armas corpo a corpo + 4 armas de fogo.
 */
public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ZombieApocMod.MOD_ID);

    // --- Materiais de crafting dropados pelos zumbis ---

    public static final RegistryObject<Item> PARTE_ZUMBI = basicItem("parte_zumbi",
            new Item.Properties());

    public static final RegistryObject<Item> CARNE_ZUMBI_QUEIMADA = basicItem("carne_zumbi_queimada",
            new Item.Properties());

    public static final RegistryObject<Item> NUCLEO_NECROMANTE = basicItem("nucleo_necromante",
            new Item.Properties());

    // --- Municao (Modulo 2) ---

    public static final RegistryObject<Item> MUNICAO_PISTOLA = basicItem("municao_pistola",
            new Item.Properties().stacksTo(64));

    public static final RegistryObject<Item> MUNICAO_RIFLE = basicItem("municao_rifle",
            new Item.Properties().stacksTo(64));

    public static final RegistryObject<Item> CARTUCHO_ESPINGARDA = basicItem("cartucho_espingarda",
            new Item.Properties().stacksTo(64));

    // --- Armas corpo a corpo (Modulo 2) - 8 no total ---

    public static final RegistryObject<Item> FACA_DE_COMBATE = ITEMS.register("faca_de_combate",
            () -> new MeleeWeaponItem(Tiers.IRON, 3.0F, -1.0F, new Item.Properties().durability(300)));

    public static final RegistryObject<Item> KATANA = ITEMS.register("katana",
            () -> new MeleeWeaponItem(Tiers.DIAMOND, 5.0F, -1.6F, new Item.Properties().durability(400)));

    public static final RegistryObject<Item> BASTAO_COM_PREGOS = ITEMS.register("bastao_com_pregos",
            () -> new MeleeWeaponItem(Tiers.STONE, 4.0F, -2.4F, new Item.Properties().durability(200)));

    public static final RegistryObject<Item> TACO_DE_BASEBALL = ITEMS.register("taco_de_baseball",
            () -> new MeleeWeaponItem(Tiers.STONE, 5.0F, -2.6F, 0.6F, new Item.Properties().durability(180)));

    public static final RegistryObject<Item> MARRETA = ITEMS.register("marreta",
            () -> new MeleeWeaponItem(Tiers.IRON, 9.0F, -3.4F, new Item.Properties().durability(350)));

    public static final RegistryObject<Item> MACHADO = ITEMS.register("machado",
            () -> new AxeWeaponItem(Tiers.IRON, 6.0F, -3.2F, new Item.Properties().durability(400)));

    public static final RegistryObject<Item> PA_DE_TRINCHEIRA = ITEMS.register("pa_de_trincheira",
            () -> new ShovelWeaponItem(Tiers.IRON, 3.0F, -2.8F, new Item.Properties().durability(350)));

    public static final RegistryObject<Item> MOTOSSERRA = ITEMS.register("motosserra",
            () -> new ChainsawItem(Tiers.NETHERITE, 7.0F, -2.0F, 4.0F, new Item.Properties().durability(250)));

    // --- Armas de fogo (Modulo 2) - 4 no total ---

    public static final RegistryObject<Item> PISTOLA = ITEMS.register("pistola",
            () -> new GunItem(MUNICAO_PISTOLA, 8, 4.0F, 1, 1.5F, 20.0D, 6,
                    ModSounds.TIRO_PISTOLA, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> RIFLE = ITEMS.register("rifle",
            () -> new GunItem(MUNICAO_RIFLE, 6, 7.0F, 1, 1.0F, 40.0D, 10,
                    ModSounds.TIRO_RIFLE, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SHOTGUN = ITEMS.register("shotgun",
            () -> new GunItem(CARTUCHO_ESPINGARDA, 2, 3.0F, 6, 12.0F, 12.0D, 20,
                    ModSounds.TIRO_SHOTGUN, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> GRANADA = ITEMS.register("granada",
            () -> new GrenadeItem(new Item.Properties().stacksTo(16)));

    // --- Comida (Modulo 3) ---

    public static final RegistryObject<Item> CARNE_APODRECIDA_PROCESSADA = ITEMS.register(
            "carne_apodrecida_processada",
            () -> new SurvivalFoodItem(0.0F, new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).build())));

    public static final RegistryObject<Item> MRE_MILITAR = ITEMS.register("mre_militar",
            () -> new SurvivalFoodItem(3.0F, new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.9F).build())));

    public static final RegistryObject<Item> ENLATADOS = ITEMS.register("enlatados",
            () -> new SurvivalFoodItem(0.0F, new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(5).saturationMod(0.5F).build())));

    public static final RegistryObject<Item> BARRA_ENERGETICA = ITEMS.register("barra_energetica",
            () -> new SurvivalFoodItem(0.0F, 8, new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(2).saturationMod(0.2F).build())));

    // --- Agua (Modulo 3) ---

    public static final RegistryObject<Item> AGUA_FILTRADA = ITEMS.register("agua_filtrada",
            () -> new DrinkableItem(8.0F, new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> AGUA_CONTAMINADA = ITEMS.register("agua_contaminada",
            () -> new DrinkableItem(6.0F,
                    new MobEffectInstance(MobEffects.CONFUSION, 400, 0),
                    0.4F,
                    new Item.Properties().stacksTo(16)));

    // --- Itens especiais (Modulo 4) ---

    public static final RegistryObject<Item> KIT_MEDICO = ITEMS.register("kit_medico",
            () -> new MedkitItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> COMBUSTIVEL = basicItem("combustivel",
            new Item.Properties().stacksTo(16));

    public static final RegistryObject<Item> BATERIA = basicItem("bateria",
            new Item.Properties().stacksTo(64));

    public static final RegistryObject<Item> PECA_ELETRONICA = basicItem("peca_eletronica",
            new Item.Properties().stacksTo(64));

    /** Helper para registrar um item "simples" (sem food/tool). */
    private static RegistryObject<Item> basicItem(String name, Item.Properties properties) {
        return ITEMS.register(name, () -> new Item(properties));
    }

    /** Helper generico usado pelos proximos modulos (armas, comida, etc). */
    public static RegistryObject<Item> register(String name, Supplier<Item> itemSupplier) {
        return ITEMS.register(name, itemSupplier);
    }
}
