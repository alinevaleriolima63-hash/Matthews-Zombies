package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.worldgen.AbandonedBuildingFeature;
import com.apocalipse.zombieapoc.worldgen.WreckedVehicleFeature;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registro das 8 estruturas do mundo. Todas usam AbandonedBuildingFeature
 * (ou WreckedVehicleFeature pro veiculo), so mudando parametros -
 * ver AbandonedBuildingFeature.java pra entender as limitacoes.
 *
 * A ligacao com o mundo (frequencia, biomas, altura) fica nos JSONs em
 * data/zombieapoc/worldgen/ - aqui so registramos a "receita" de cada
 * predio em codigo.
 */
public class ModFeatures {

    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, ZombieApocMod.MOD_ID);

    private static ResourceLocation loot(String nome) {
        return new ResourceLocation(ZombieApocMod.MOD_ID, "chests/" + nome);
    }

    public static final RegistryObject<Feature<?>> CASA_ABANDONADA = FEATURES.register("casa_abandonada",
            () -> new AbandonedBuildingFeature(7, 7, 4,
                    Blocks.COBBLESTONE, Blocks.OAK_PLANKS, Blocks.SPRUCE_PLANKS,
                    0.25F, loot("casa"), 1));

    public static final RegistryObject<Feature<?>> PREDIO_DESTRUIDO = FEATURES.register("predio_destruido",
            () -> new AbandonedBuildingFeature(9, 9, 5,
                    Blocks.STONE_BRICKS, Blocks.COBBLESTONE, Blocks.STONE_BRICKS,
                    0.45F, loot("predio_destruido"), 1));

    public static final RegistryObject<Feature<?>> HOSPITAL_ABANDONADO = FEATURES.register("hospital_abandonado",
            () -> new AbandonedBuildingFeature(11, 9, 5,
                    Blocks.WHITE_CONCRETE, Blocks.SMOOTH_STONE, Blocks.WHITE_CONCRETE,
                    0.2F, loot("hospital"), 2));

    public static final RegistryObject<Feature<?>> DELEGACIA_ABANDONADA = FEATURES.register("delegacia_abandonada",
            () -> new AbandonedBuildingFeature(9, 9, 4,
                    Blocks.POLISHED_ANDESITE, Blocks.STONE, Blocks.POLISHED_ANDESITE,
                    0.3F, loot("delegacia"), 2));

    public static final RegistryObject<Feature<?>> SUPERMERCADO_ABANDONADO = FEATURES.register(
            "supermercado_abandonado",
            () -> new AbandonedBuildingFeature(11, 11, 5,
                    Blocks.LIGHT_GRAY_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE,
                    0.25F, loot("supermercado"), 3));

    public static final RegistryObject<Feature<?>> POSTO_GASOLINA = FEATURES.register("posto_gasolina",
            () -> new AbandonedBuildingFeature(7, 7, 4,
                    Blocks.RED_CONCRETE, Blocks.SMOOTH_STONE, Blocks.RED_CONCRETE,
                    0.3F, loot("posto_gasolina"), 1));

    public static final RegistryObject<Feature<?>> BASE_MILITAR = FEATURES.register("base_militar",
            () -> new AbandonedBuildingFeature(11, 11, 5,
                    Blocks.COBBLED_DEEPSLATE, Blocks.STONE, Blocks.COBBLED_DEEPSLATE,
                    0.15F, loot("base_militar"), 2));

    public static final RegistryObject<Feature<?>> VEICULO_ABANDONADO = FEATURES.register("veiculo_abandonado",
            () -> new WreckedVehicleFeature(loot("veiculo_abandonado")));
}
