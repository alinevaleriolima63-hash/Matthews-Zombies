package com.apocalipse.zombieapoc.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Enviado do servidor pro cliente sempre que a sede do jogador muda,
 * pra HUD (ThirstHudOverlay) saber o valor atual sem precisar
 * calcular nada no cliente (o cliente so guarda o ultimo valor
 * recebido, em ClientThirstData).
 */
public class ThirstSyncPacket {

    private final float sede;

    public ThirstSyncPacket(float sede) {
        this.sede = sede;
    }

    public static void encode(ThirstSyncPacket pacote, FriendlyByteBuf buf) {
        buf.writeFloat(pacote.sede);
    }

    public static ThirstSyncPacket decode(FriendlyByteBuf buf) {
        return new ThirstSyncPacket(buf.readFloat());
    }

    public static void handle(ThirstSyncPacket pacote, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> ClientThirstData.setThirst(pacote.sede));
        ctx.setPacketHandled(true);
    }
}
