package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * Aba unica do inventario criativo para todos os itens do mod.
 * Os itens sao adicionados ao displayItems() aqui; cada modulo novo
 * deve adicionar seus RegistryObjects nesta lista via output.accept(...).
 */
public class ModCreativeTab {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ZombieApocMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> ZOMBIE_APOC_TAB = CREATIVE_MODE_TABS.register(
            "zombieapoc_tab",
            () -> CreativeModeTab.builder()
                    .icon(() -> new ItemStack(ModItems.PARTE_ZUMBI.get()))
                    .title(Component.translatable("itemGroup.zombieapoc"))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.PARTE_ZUMBI.get());
                        output.accept(ModItems.CARNE_ZUMBI_QUEIMADA.get());
                        output.accept(ModItems.NUCLEO_NECROMANTE.get());

                        output.accept(ModItems.FACA_DE_COMBATE.get());
                        output.accept(ModItems.KATANA.get());
                        output.accept(ModItems.BASTAO_COM_PREGOS.get());
                        output.accept(ModItems.TACO_DE_BASEBALL.get());
                        output.accept(ModItems.MARRETA.get());
                        output.accept(ModItems.MACHADO.get());
                        output.accept(ModItems.PA_DE_TRINCHEIRA.get());
                        output.accept(ModItems.MOTOSSERRA.get());

                        output.accept(ModItems.PISTOLA.get());
                        output.accept(ModItems.RIFLE.get());
                        output.accept(ModItems.SHOTGUN.get());
                        output.accept(ModItems.GRANADA.get());
                        output.accept(ModItems.MUNICAO_PISTOLA.get());
                        output.accept(ModItems.MUNICAO_RIFLE.get());
                        output.accept(ModItems.CARTUCHO_ESPINGARDA.get());

                        output.accept(ModItems.CARNE_APODRECIDA_PROCESSADA.get());
                        output.accept(ModItems.MRE_MILITAR.get());
                        output.accept(ModItems.ENLATADOS.get());
                        output.accept(ModItems.BARRA_ENERGETICA.get());
                        output.accept(ModItems.AGUA_FILTRADA.get());
                        output.accept(ModItems.AGUA_CONTAMINADA.get());

                        output.accept(ModItems.KIT_MEDICO.get());
                        output.accept(ModItems.COMBUSTIVEL.get());
                        output.accept(ModItems.BATERIA.get());
                        output.accept(ModItems.PECA_ELETRONICA.get());
                        // Modulo 5+ adiciona itens de estrutura/loot aqui.
                    })
                    .build());
}
