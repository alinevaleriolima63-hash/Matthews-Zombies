package com.apocalipse.zombieapoc;

import com.apocalipse.zombieapoc.registry.ModCreativeTab;
import com.apocalipse.zombieapoc.registry.ModEntities;
import com.apocalipse.zombieapoc.registry.ModItems;
import com.apocalipse.zombieapoc.registry.ModSounds;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Classe principal do mod. Registra todos os DeferredRegister nos
 * event bus corretos. Nenhuma logica de gameplay deve morar aqui:
 * este arquivo so faz "fiacao" (wiring) entre os modulos.
 */
@Mod(ZombieApocMod.MOD_ID)
public class ZombieApocMod {

    public static final String MOD_ID = "zombieapoc";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public ZombieApocMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Registries (modulo de entidades/itens/sons)
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModSounds.SOUND_EVENTS.register(modEventBus);
        ModCreativeTab.CREATIVE_MODE_TABS.register(modEventBus);
        com.apocalipse.zombieapoc.registry.ModFeatures.FEATURES.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerAttributes);

        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("[ZombieApoc] Modulo 1 carregado: core + zumbis.");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(com.apocalipse.zombieapoc.network.ModNetworking::register);
        LOGGER.info("[ZombieApoc] Common setup concluido.");
    }

    /**
     * Registra os atributos (vida, velocidade, dano, etc.) de cada
     * EntityType customizado. Isso e OBRIGATORIO no Forge 1.20.1:
     * esquecer isso causa crash imediato ao spawnar a entidade.
     */
    private void registerAttributes(final EntityAttributeCreationEvent event) {
        event.put(ModEntities.APOCALYPSE_ZOMBIE.get(),
                com.apocalipse.zombieapoc.entity.ApocalypseZombieEntity.createAttributes().build());
    }
}
