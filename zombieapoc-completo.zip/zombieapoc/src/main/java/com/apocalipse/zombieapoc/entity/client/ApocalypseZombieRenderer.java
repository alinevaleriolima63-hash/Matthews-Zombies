package com.apocalipse.zombieapoc.entity.client;

import com.apocalipse.zombieapoc.entity.ApocalypseTimeUtil;
import com.apocalipse.zombieapoc.entity.ApocalypseZombieEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

/**
 * Reaproveita o ZombieRenderer vanilla (modelo, layers de armadura,
 * animacoes de braco quebrando porta, etc.) e so troca:
 *  - a textura, de acordo com a variante (5 texturas diferentes)
 *  - a escala visual, para o zumbi mutante ficar maior de verdade
 *
 * Isso reduz MUITO a chance de bug comparado a escrever um
 * EntityModel do zero: a geometria/animacao ja e testada pela Mojang.
 */
public class ApocalypseZombieRenderer extends ZombieRenderer {

    public ApocalypseZombieRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(Zombie entity) {
        if (entity instanceof ApocalypseZombieEntity apocalypseZombie) {
            boolean noite = ApocalypseTimeUtil.ehNoite(entity.level());
            return noite ? apocalypseZombie.getVariant().getTextureNoturna()
                    : apocalypseZombie.getVariant().getTexture();
        }
        return super.getTextureLocation(entity);
    }

    @Override
    protected void scale(Zombie livingEntity, PoseStack poseStack, float partialTickTime) {
        super.scale(livingEntity, poseStack, partialTickTime);
        if (livingEntity instanceof ApocalypseZombieEntity apocalypseZombie) {
            float escala = apocalypseZombie.getVariant().getScale();
            poseStack.scale(escala, escala, escala);
        }
    }
}
