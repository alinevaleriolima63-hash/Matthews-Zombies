package com.apocalipse.zombieapoc.network;

/**
 * So guarda o ultimo valor de sede recebido do servidor. Classe
 * "burra" de proposito (sem imports de client do Minecraft) pra
 * poder ser carregada com seguranca tanto no cliente quanto no
 * servidor dedicado, ja que o pacote que a usa tambem e carregado
 * nos dois lados.
 */
public class ClientThirstData {

    private static float sedeAtual = 20.0F;

    public static float getThirst() {
        return sedeAtual;
    }

    public static void setThirst(float valor) {
        sedeAtual = valor;
    }
}
