package com.apocalipse.zombieapoc.capability;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;

public class Thirst implements IThirst {

    private static final float MAXIMO = 20.0F;

    private float sede = MAXIMO;

    @Override
    public float getThirst() {
        return sede;
    }

    @Override
    public void setThirst(float value) {
        this.sede = Mth.clamp(value, 0.0F, MAXIMO);
    }

    @Override
    public void addThirst(float amount) {
        setThirst(this.sede + amount);
    }

    @Override
    public float getMaxThirst() {
        return MAXIMO;
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("Sede", sede);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        if (tag.contains("Sede")) {
            this.sede = tag.getFloat("Sede");
        }
    }
}
