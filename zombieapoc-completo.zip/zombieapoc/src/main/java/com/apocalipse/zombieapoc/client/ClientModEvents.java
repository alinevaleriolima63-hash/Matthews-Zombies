package com.apocalipse.zombieapoc.client;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.entity.client.ApocalypseZombieRenderer;
import com.apocalipse.zombieapoc.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Eventos exclusivos de CLIENTE (renderizacao). Nunca deve ser
 * carregado no lado servidor: por isso bus = MOD e value = Dist.CLIENT.
 */
@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.APOCALYPSE_ZOMBIE.get(), ApocalypseZombieRenderer::new);
        event.registerEntityRenderer(ModEntities.GRENADE.get(), ThrownItemRenderer::new);
    }
}
