package com.apocalipse.zombieapoc.capability;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.apocalipse.zombieapoc.ZombieApocMod;

/**
 * NOTA: em algumas builds do Forge 1.20.1 o metodo de registro pode
 * ter um nome levemente diferente. Se `event.register(IThirst.class)`
 * nao compilar, procure por "RegisterCapabilitiesEvent" na sua versao
 * exata do Forge (autocomplete da IDE resolve rapido).
 */
@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID)
public class ModCapabilities {

    public static final Capability<IThirst> THIRST = CapabilityManager.get(new CapabilityToken<>() {});

    @SubscribeEvent
    public static void register(RegisterCapabilitiesEvent event) {
        event.register(IThirst.class);
    }
}
