package com.apocalipse.zombieapoc.capability;

import com.apocalipse.zombieapoc.ZombieApocMod;
import com.apocalipse.zombieapoc.network.ModNetworking;
import com.apocalipse.zombieapoc.network.ThirstSyncPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = ZombieApocMod.MOD_ID)
public class ThirstEvents {

    private static final ResourceLocation THIRST_CAP_ID = new ResourceLocation(ZombieApocMod.MOD_ID, "thirst");

    private static final int JANELA_COMBATE_TICKS = 200; // 10s: conta como "em combate"
    private static final int INTERVALO_DECAIMENTO_TICKS = 100; // a cada 5s reduz a sede
    private static final float DECAIMENTO_BASE = 0.15F;
    private static final float DECAIMENTO_CORRENDO_EXTRA = 0.15F;
    private static final float DECAIMENTO_COMBATE_EXTRA = 0.20F;

    /** Ultimo momento (game time) em que cada jogador esteve em combate. */
    private static final Map<UUID, Long> ULTIMO_COMBATE = new HashMap<>();

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            ThirstProvider provider = new ThirstProvider();
            event.addCapability(THIRST_CAP_ID, provider);
            event.addListener(provider::invalidate);
        }
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        event.getOriginal().getCapability(ModCapabilities.THIRST).ifPresent(sedeAntiga -> {
            event.getEntity().getCapability(ModCapabilities.THIRST).ifPresent(sedeNova -> {
                // Morreu -> volta sede cheia (igual a fome vanilla). Trocou de
                // dimensao/outro clone que nao e morte -> mantem o valor.
                sedeNova.setThirst(event.isWasDeath() ? sedeNova.getMaxThirst() : sedeAntiga.getThirst());
            });
        });
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        long agora = event.getEntity().level().getGameTime();
        if (event.getEntity() instanceof Player alvo) {
            ULTIMO_COMBATE.put(alvo.getUUID(), agora);
        }
        if (event.getSource().getEntity() instanceof Player atacante) {
            ULTIMO_COMBATE.put(atacante.getUUID(), agora);
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        ULTIMO_COMBATE.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onPlayerTick(net.minecraftforge.event.TickEvent.PlayerTickEvent event) {
        if (event.phase != net.minecraftforge.event.TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide) {
            return;
        }
        long gameTime = player.level().getGameTime();
        if (gameTime % INTERVALO_DECAIMENTO_TICKS != 0) {
            return;
        }
        if (player.getAbilities().instabuild) {
            return; // criativo nao sente sede
        }

        player.getCapability(ModCapabilities.THIRST).ifPresent(sede -> {
            float decaimento = DECAIMENTO_BASE;
            if (player.isSprinting()) {
                decaimento += DECAIMENTO_CORRENDO_EXTRA;
            }
            Long ultimoCombate = ULTIMO_COMBATE.get(player.getUUID());
            if (ultimoCombate != null && gameTime - ultimoCombate < JANELA_COMBATE_TICKS) {
                decaimento += DECAIMENTO_COMBATE_EXTRA;
            }
            sede.addThirst(-decaimento);

            if (sede.getThirst() <= 0.0F) {
                player.hurt(player.damageSources().starve(), 1.0F);
            } else if (sede.getThirst() <= 4.0F) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 140, 0, false, false));
            }

            if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                ModNetworking.CHANNEL.send(
                        net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> serverPlayer),
                        new ThirstSyncPacket(sede.getThirst()));
            }
        });
    }
}
