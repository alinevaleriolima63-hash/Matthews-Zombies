package com.apocalipse.zombieapoc.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.WorldGenLevel;

/**
 * Gera um predio abandonado retangular simples: fundacao, paredes com
 * "janelas quebradas" (buracos), teto, ruina aleatoria (blocos
 * faltando + detrito no chao) e 1-2 bau(s) com loot table propria.
 *
 * Uma UNICA classe atende TODOS os tipos de predio do mod (casa,
 * hospital, delegacia, etc) - cada tipo e so uma instancia desta
 * classe com parametros diferentes (tamanho/material/loot), registrada
 * em ModFeatures.java. Mesmo principio usado pros zumbis (1 classe,
 * varias variantes) e pras armas de fogo (1 classe, varias configs):
 * menos codigo duplicado = menos superficie de bug.
 *
 * LIMITACAO IMPORTANTE (leia): predios ficam limitados a ~11x11 blocos
 * pra caber com folga dentro de 1 chunk (16x16). Isso NAO gera
 * "cidades gigantes" continuas feitas de varios predios conectados -
 * isso exigiria o sistema de Jigsaw Structure do Minecraft, que
 * precisa de arquivos de estrutura .nbt construidos dentro do jogo
 * (com structure blocks) - nao da pra criar esses arquivos aqui sem
 * rodar o Minecraft. O resultado real e: predios individuais variados
 * espalhados por todo o mapa, com frequencia configurada pra criar a
 * SENSACAO de area urbana abandonada quando varios spawnam perto.
 */
public class AbandonedBuildingFeature extends Feature<NoneFeatureConfiguration> {

    private final int largura;
    private final int profundidade;
    private final int altura;
    private final Block blocoParede;
    private final Block blocoChao;
    private final Block blocoTeto;
    private final float chanceRuina;
    private final ResourceLocation lootTable;
    private final int numBaus;

    public AbandonedBuildingFeature(int largura, int profundidade, int altura, Block blocoParede,
                                     Block blocoChao, Block blocoTeto, float chanceRuina,
                                     ResourceLocation lootTable, int numBaus) {
        super(NoneFeatureConfiguration.CODEC);
        this.largura = largura;
        this.profundidade = profundidade;
        this.altura = altura;
        this.blocoParede = blocoParede;
        this.blocoChao = blocoChao;
        this.blocoTeto = blocoTeto;
        this.chanceRuina = chanceRuina;
        this.lootTable = lootTable;
        this.numBaus = numBaus;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        RandomSource random = context.random();
        BlockPos origem = context.origin();

        BlockPos base = encontrarBase(level, origem);
        if (!areaAdequada(level, base)) {
            return false;
        }

        construirFundacaoEChao(level, base);
        construirParedes(level, base, random);
        construirTeto(level, base);
        aplicarRuina(level, base, random);
        colocarLoot(level, base, random);

        return true;
    }

    private BlockPos encontrarBase(WorldGenLevel level, BlockPos origem) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, origem.getX(), origem.getZ());
        return new BlockPos(origem.getX(), y, origem.getZ());
    }

    private boolean areaAdequada(WorldGenLevel level, BlockPos base) {
        int y0 = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, base.getX(), base.getZ());
        int y1 = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, base.getX() + largura - 1, base.getZ());
        int y2 = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, base.getX(), base.getZ() + profundidade - 1);
        int y3 = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG,
                base.getX() + largura - 1, base.getZ() + profundidade - 1);
        int max = Math.max(Math.max(y0, y1), Math.max(y2, y3));
        int min = Math.min(Math.min(y0, y1), Math.min(y2, y3));
        if (max - min > 4) {
            return false; // terreno inclinado demais, evita predio "flutuando"
        }

        BlockPos centro = new BlockPos(base.getX() + largura / 2, base.getY(), base.getZ() + profundidade / 2);
        return !level.getFluidState(centro).is(FluidTags.WATER) && !level.getFluidState(centro).is(FluidTags.LAVA);
    }

    private void construirFundacaoEChao(WorldGenLevel level, BlockPos base) {
        for (int x = 0; x < largura; x++) {
            for (int z = 0; z < profundidade; z++) {
                level.setBlock(base.offset(x, -1, z), blocoChao.defaultBlockState(), 3);
                level.setBlock(base.offset(x, 0, z), blocoChao.defaultBlockState(), 3);
            }
        }
    }

    private void construirParedes(WorldGenLevel level, BlockPos base, RandomSource random) {
        int meioAltura = Math.max(1, altura / 2);
        int portaX = largura / 2;

        for (int y = 1; y <= altura; y++) {
            for (int x = 0; x < largura; x++) {
                for (int z = 0; z < profundidade; z++) {
                    boolean borda = x == 0 || x == largura - 1 || z == 0 || z == profundidade - 1;
                    if (!borda) {
                        continue;
                    }
                    boolean quina = (x == 0 || x == largura - 1) && (z == 0 || z == profundidade - 1);
                    boolean janela = !quina && y == meioAltura && (x % 3 == 0 || z % 3 == 0);
                    boolean porta = z == 0 && x == portaX && (y == 1 || y == 2);

                    BlockPos pos = base.offset(x, y, z);
                    if (janela || porta) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    } else {
                        level.setBlock(pos, blocoParede.defaultBlockState(), 3);
                    }
                }
            }
        }
    }

    private void construirTeto(WorldGenLevel level, BlockPos base) {
        for (int x = 0; x < largura; x++) {
            for (int z = 0; z < profundidade; z++) {
                level.setBlock(base.offset(x, altura + 1, z), blocoTeto.defaultBlockState(), 3);
            }
        }
    }

    private void aplicarRuina(WorldGenLevel level, BlockPos base, RandomSource random) {
        int tentativas = (int) (largura * profundidade * chanceRuina * 2);
        for (int i = 0; i < tentativas; i++) {
            int x = random.nextInt(largura);
            int z = random.nextInt(profundidade);
            boolean borda = x == 0 || x == largura - 1 || z == 0 || z == profundidade - 1;

            if (borda) {
                int y = 1 + random.nextInt(altura);
                if (random.nextFloat() < chanceRuina) {
                    level.setBlock(base.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                }
            }
            if (random.nextFloat() < 0.35F) {
                Block detrito = random.nextBoolean() ? Blocks.COBBLESTONE : Blocks.GRAVEL;
                level.setBlock(base.offset(x, 1, z), detrito.defaultBlockState(), 3);
            }
        }
    }

    private void colocarLoot(WorldGenLevel level, BlockPos base, RandomSource random) {
        for (int i = 0; i < numBaus; i++) {
            int x = 1 + random.nextInt(Math.max(1, largura - 2));
            int z = 1 + random.nextInt(Math.max(1, profundidade - 2));
            BlockPos posBau = base.offset(x, 1, z);

            level.setBlock(posBau, Blocks.CHEST.defaultBlockState(), 3);
            BlockEntity blockEntity = level.getBlockEntity(posBau);
            if (blockEntity instanceof RandomizableContainerBlockEntity container) {
                container.setLootTable(lootTable, random.nextLong());
            }
        }
    }
}
