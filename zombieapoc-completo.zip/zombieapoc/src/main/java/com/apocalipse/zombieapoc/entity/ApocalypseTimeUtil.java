package com.apocalipse.zombieapoc.entity;

import net.minecraft.world.level.Level;

/**
 * Checagem de "e noite?" compartilhada entre a entidade (bonus de
 * velocidade) e o renderer (textura com olhos vermelhos), pra nao
 * duplicar a mesma logica em 2 lugares.
 *
 * Usa o intervalo de tempo 13000-23000, que e o mesmo que o Minecraft
 * usa pra decidir se mobs hostis podem spawnar de dia na superficie -
 * ou seja, "noite" aqui significa exatamente o mesmo que pro resto do
 * jogo, nao um horario arbitrario.
 */
public final class ApocalypseTimeUtil {

    private ApocalypseTimeUtil() {
    }

    public static boolean ehNoite(Level level) {
        long tempo = level.getDayTime() % 24000L;
        return tempo >= 13000L && tempo < 23000L;
    }
}
