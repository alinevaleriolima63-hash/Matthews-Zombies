package com.apocalipse.zombieapoc.item;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Kit medico: cura uma quantidade fixa de vida e remove efeitos
 * negativos comuns (veneno, wither, nausea, fraqueza). Tem cooldown
 * pra impedir spam. So e consumido se realmente curou algo (nao gasta
 * o item se o jogador ja estiver com vida cheia e sem efeitos ruins).
 */
public class MedkitItem extends Item {

    private static final float CURA = 10.0F;
    private static final int COOLDOWN_TICKS = 60;

    private static final List<MobEffect> EFEITOS_REMOVIDOS = List.of(
            MobEffects.POISON, MobEffects.WITHER, MobEffects.CONFUSION, MobEffects.WEAKNESS);

    public MedkitItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        boolean precisaCurar = player.getHealth() < player.getMaxHealth();
        boolean temEfeitoRuim = EFEITOS_REMOVIDOS.stream().anyMatch(player::hasEffect);
        if (!precisaCurar && !temEfeitoRuim) {
            return InteractionResultHolder.pass(stack);
        }

        if (!level.isClientSide) {
            player.heal(CURA);
            EFEITOS_REMOVIDOS.forEach(player::removeEffect);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6F, 1.6F);
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
