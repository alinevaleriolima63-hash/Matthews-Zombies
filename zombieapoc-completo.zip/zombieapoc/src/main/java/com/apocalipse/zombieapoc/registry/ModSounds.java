package com.apocalipse.zombieapoc.registry;

import com.apocalipse.zombieapoc.ZombieApocMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registro de SoundEvents customizados.
 * IMPORTANTE: registrar o SoundEvent aqui NAO cria o audio.
 * E necessario colocar um arquivo .ogg real em
 * src/main/resources/assets/zombieapoc/sounds/<nome>.ogg
 * e referencia-lo em assets/zombieapoc/sounds.json (arquivo tambem
 * incluido neste projeto). Sem o .ogg, o som simplesmente nao toca
 * (nao gera crash, mas fica mudo) - por isso nao conta como "bug",
 * mas precisa ser resolvido antes do lancamento final.
 */
public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ZombieApocMod.MOD_ID);

    public static final RegistryObject<SoundEvent> ZUMBI_MUTANTE_ROAR = registerSound("zumbi_mutante_roar");
    public static final RegistryObject<SoundEvent> ZUMBI_NECROMANTE_CAST = registerSound("zumbi_necromante_cast");
    public static final RegistryObject<SoundEvent> ZUMBI_QUEIMADO_HISS = registerSound("zumbi_queimado_hiss");

    public static final RegistryObject<SoundEvent> TIRO_PISTOLA = registerSound("tiro_pistola");
    public static final RegistryObject<SoundEvent> TIRO_RIFLE = registerSound("tiro_rifle");
    public static final RegistryObject<SoundEvent> TIRO_SHOTGUN = registerSound("tiro_shotgun");

    private static RegistryObject<SoundEvent> registerSound(String name) {
        ResourceLocation id = new ResourceLocation(ZombieApocMod.MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
}
