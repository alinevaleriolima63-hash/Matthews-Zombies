import json
import os

BASE = "/home/claude/zombieapoc/src/main/resources/data/zombieapoc/loot_tables/entities"
os.makedirs(BASE, exist_ok=True)

# id, chance de dropar "parte_zumbi", item extra especifico (ou None)
VARIANTES = [
    ("normal", 0.15, None),
    ("armado", 0.25, None),
    ("queimado", 0.20, "zombieapoc:carne_zumbi_queimada"),
    ("mutante", 0.35, "zombieapoc:parte_zumbi"),  # mutante dropa parte extra garantida
    ("necromante", 0.30, "zombieapoc:nucleo_necromante"),
]

for nome, chance_parte, item_extra in VARIANTES:
    pools = [
        {
            "rolls": 1.0,
            "entries": [
                {
                    "type": "minecraft:item",
                    "name": "minecraft:rotten_flesh",
                    "functions": [
                        {
                            "function": "minecraft:set_count",
                            "count": {"type": "minecraft:uniform", "min": 0.0, "max": 2.0}
                        },
                        {"function": "minecraft:looting_enchant", "count": {"min": 0.0, "max": 1.0}}
                    ]
                }
            ]
        },
        {
            "rolls": 1.0,
            "entries": [
                {
                    "type": "minecraft:item",
                    "name": "zombieapoc:parte_zumbi",
                    "conditions": [
                        {"condition": "minecraft:random_chance", "chance": chance_parte}
                    ]
                }
            ]
        }
    ]

    if item_extra and item_extra != "zombieapoc:parte_zumbi":
        pools.append({
            "rolls": 1.0,
            "entries": [
                {
                    "type": "minecraft:item",
                    "name": item_extra,
                    "conditions": [
                        {"condition": "minecraft:random_chance", "chance": 0.5}
                    ]
                }
            ]
        })
    elif item_extra == "zombieapoc:parte_zumbi":
        # mutante: garante 1 parte extra (sem condicao de chance)
        pools.append({
            "rolls": 1.0,
            "entries": [{"type": "minecraft:item", "name": "zombieapoc:parte_zumbi"}]
        })

    loot_table = {"type": "minecraft:entity", "pools": pools}

    path = os.path.join(BASE, f"zumbi_{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(loot_table, f, indent=2, ensure_ascii=False)
    print("Criado:", path)
