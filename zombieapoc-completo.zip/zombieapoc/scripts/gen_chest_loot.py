import json
import os

BASE = "/home/claude/zombieapoc/src/main/resources/data/zombieapoc/loot_tables/chests"
os.makedirs(BASE, exist_ok=True)


def pool(rolls, entries):
    return {"rolls": rolls, "entries": entries}


def item(nome, count_min=1, count_max=1, chance=None):
    entry = {"type": "minecraft:item", "name": f"zombieapoc:{nome}" if ":" not in nome else nome}
    functions = []
    if count_min != 1 or count_max != 1:
        functions.append({
            "function": "minecraft:set_count",
            "count": {"type": "minecraft:uniform", "min": count_min, "max": count_max}
        })
    if functions:
        entry["functions"] = functions
    if chance is not None:
        entry["conditions"] = [{"condition": "minecraft:random_chance", "chance": chance}]
    return entry


TABELAS = {
    "casa": {
        "type": "minecraft:chest",
        "pools": [
            pool(2, [item("carne_apodrecida_processada", 1, 2), item("enlatados", 1, 2)]),
            pool(1, [item("agua_filtrada", 1, 2)]),
            pool(1, [item("kit_medico", chance=0.2)]),
            pool(1, [item("bateria", 1, 2, chance=0.25)]),
        ]
    },
    "predio_destruido": {
        "type": "minecraft:chest",
        "pools": [
            pool(1, [item("parte_zumbi", 1, 2)]),
            pool(1, [item("carne_apodrecida_processada", chance=0.5)]),
            pool(1, [item("municao_pistola", 1, 3, chance=0.3)]),
            pool(1, [item("bateria", chance=0.2)]),
        ]
    },
    "hospital": {
        "type": "minecraft:chest",
        "pools": [
            pool(2, [item("kit_medico", 1, 2)]),
            pool(1, [item("agua_filtrada", 1, 2)]),
            pool(1, [item("peca_eletronica", 1, 2, chance=0.35)]),
            pool(1, [item("bateria", chance=0.3)]),
        ]
    },
    "delegacia": {
        "type": "minecraft:chest",
        "pools": [
            pool(2, [item("municao_pistola", 2, 6)]),
            pool(1, [item("municao_rifle", 1, 4, chance=0.5)]),
            pool(1, [item("pistola", chance=0.25)]),
            pool(1, [item("cartucho_espingarda", 1, 3, chance=0.3)]),
        ]
    },
    "supermercado": {
        "type": "minecraft:chest",
        "pools": [
            pool(3, [item("enlatados", 1, 3), item("carne_apodrecida_processada", 1, 2),
                     item("barra_energetica", 1, 2)]),
            pool(1, [item("mre_militar", chance=0.3)]),
            pool(1, [item("agua_filtrada", 1, 2, chance=0.6), item("agua_contaminada", 1, 2, chance=0.4)]),
        ]
    },
    "posto_gasolina": {
        "type": "minecraft:chest",
        "pools": [
            pool(1, [item("combustivel", 2, 4)]),
            pool(1, [item("bateria", 1, 2, chance=0.4)]),
            pool(1, [item("enlatados", chance=0.3)]),
        ]
    },
    "base_militar": {
        "type": "minecraft:chest",
        "pools": [
            pool(2, [item("municao_rifle", 3, 8), item("cartucho_espingarda", 2, 5)]),
            pool(1, [item("granada", 1, 2, chance=0.4)]),
            pool(1, [item("rifle", chance=0.2), item("shotgun", chance=0.15)]),
            pool(1, [item("kit_medico", 1, 2)]),
        ]
    },
    "veiculo_abandonado": {
        "type": "minecraft:chest",
        "pools": [
            pool(1, [item("combustivel", 1, 2)]),
            pool(1, [item("bateria", chance=0.4)]),
            pool(1, [item("municao_pistola", 1, 2, chance=0.25)]),
        ]
    },
}

for nome, tabela in TABELAS.items():
    path = os.path.join(BASE, f"{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(tabela, f, indent=2, ensure_ascii=False)
    print("Criado:", path)
