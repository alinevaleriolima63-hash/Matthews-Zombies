import os
from PIL import Image, ImageDraw

BASE = "/home/claude/zombieapoc/src/main/resources/assets/zombieapoc"
ITEM_DIR = os.path.join(BASE, "textures/item")
MODEL_DIR = os.path.join(BASE, "models/item")
SIZE = 64


def clamp(v):
    return max(0, min(255, int(v)))


def shade(color, factor):
    r, g, b = color
    return (clamp(r * factor), clamp(g * factor), clamp(b * factor), 255)


def save_icon(nome, draw_fn):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_fn(draw)
    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_item_model(nome):
    content = (
        '{\n  "parent": "item/generated",\n  "textures": {\n'
        f'    "layer0": "zombieapoc:item/{nome}"\n  }}\n}}\n'
    )
    path = os.path.join(MODEL_DIR, f"{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Modelo criado:", path)


def kit_medico(draw):
    corpo = (235, 235, 230)
    escuro = shade(corpo, 0.75)
    draw.rounded_rectangle([12, 16, 52, 48], radius=5, fill=(*corpo, 255), outline=escuro, width=3)
    # cruz vermelha
    draw.rectangle([27, 22, 37, 42], fill=(200, 40, 40, 255))
    draw.rectangle([18, 27, 46, 37], fill=(200, 40, 40, 255))


def combustivel(draw):
    corpo = (200, 80, 40)
    escuro = shade(corpo, 0.7)
    draw.rounded_rectangle([16, 10, 48, 52], radius=6, fill=(*corpo, 255), outline=escuro, width=3)
    draw.rectangle([24, 4, 40, 12], fill=(80, 80, 80, 255))  # bocal
    draw.rectangle([18, 30, 46, 38], fill=(*shade(corpo, 1.3)[:3], 255))  # faixa/label


def bateria(draw):
    corpo = (60, 160, 90)
    escuro = shade(corpo, 0.7)
    draw.rounded_rectangle([20, 10, 44, 50], radius=3, fill=(*corpo, 255), outline=escuro, width=2)
    draw.rectangle([27, 4, 37, 10], fill=(90, 90, 90, 255))  # terminal +
    draw.rectangle([22, 30, 42, 36], fill=(230, 230, 230, 255))  # faixa +/-


def peca_eletronica(draw):
    placa = (40, 110, 60)
    escuro = shade(placa, 0.7)
    draw.rectangle([14, 14, 50, 50], fill=(*placa, 255), outline=escuro, width=2)
    dourado = (210, 170, 60, 255)
    for x in (20, 28, 36, 44):
        draw.line([x, 14, x, 8], fill=dourado, width=2)
        draw.line([x, 50, x, 56], fill=dourado, width=2)
    draw.rectangle([24, 24, 40, 40], fill=(20, 20, 25, 255))  # chip central


save_icon("kit_medico", kit_medico)
save_icon("combustivel", combustivel)
save_icon("bateria", bateria)
save_icon("peca_eletronica", peca_eletronica)

for nome in ["kit_medico", "combustivel", "bateria", "peca_eletronica"]:
    make_item_model(nome)

print("OK - modulo 4: texturas e modelos gerados.")
