import os
from PIL import Image, ImageDraw

BASE = "/home/claude/zombieapoc/src/main/resources/assets/zombieapoc"
ITEM_DIR = os.path.join(BASE, "textures/item")
GUI_DIR = os.path.join(BASE, "textures/gui")
MODEL_DIR = os.path.join(BASE, "models/item")
os.makedirs(ITEM_DIR, exist_ok=True)
os.makedirs(GUI_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

SIZE = 64


def clamp(v):
    return max(0, min(255, int(v)))


def shade(color, factor):
    r, g, b = color
    return (clamp(r * factor), clamp(g * factor), clamp(b * factor), 255)


def make_food_icon(nome, color, formato="carne"):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    escuro = shade(color, 0.6)
    claro = shade(color, 1.3)

    if formato == "carne":
        draw.ellipse([16, 20, 48, 46], fill=(*color, 255), outline=escuro, width=3)
        draw.line([20, 26, 44, 26], fill=escuro, width=2)
    elif formato == "lata":
        draw.rectangle([18, 14, 46, 48], fill=(*color, 255), outline=escuro, width=3)
        draw.rectangle([18, 14, 46, 20], fill=(*claro[:3], 255))
        draw.rectangle([18, 42, 46, 48], fill=(*claro[:3], 255))
    elif formato == "embalagem":
        draw.rounded_rectangle([16, 12, 48, 50], radius=6, fill=(*color, 255), outline=escuro, width=3)
        draw.rectangle([20, 22, 44, 30], fill=(*claro[:3], 255))
    elif formato == "barra":
        draw.rounded_rectangle([12, 24, 52, 40], radius=4, fill=(*color, 255), outline=escuro, width=2)
        for x in range(18, 50, 8):
            draw.line([x, 24, x, 40], fill=escuro, width=1)

    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_water_icon(nome, cor_liquido):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    vidro = (200, 220, 230, 140)
    draw.rounded_rectangle([22, 8, 42, 20], radius=3, fill=vidro)  # gargalo
    draw.polygon([(16, 20), (48, 20), (44, 54), (20, 54)], fill=vidro, outline=(150, 170, 180, 255))
    draw.polygon([(18, 30), (46, 30), (43, 52), (21, 52)], fill=(*cor_liquido, 230))
    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_item_model(nome, parent="item/generated"):
    content = (
        "{\n"
        f'  "parent": "{parent}",\n'
        '  "textures": {\n'
        f'    "layer0": "zombieapoc:item/{nome}"\n'
        "  }\n"
        "}\n"
    )
    path = os.path.join(MODEL_DIR, f"{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Modelo criado:", path)


def make_hud_icon(nome, cor, vazio=False):
    """Icone 9x9 (mesmo tamanho da fome vanilla) - gota de agua."""
    img = Image.new("RGBA", (9, 9), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    if vazio:
        draw.polygon([(4, 1), (7, 5), (4, 8), (1, 5)], outline=(60, 60, 70, 255))
    else:
        draw.polygon([(4, 1), (7, 5), (4, 8), (1, 5)], fill=(*cor, 255), outline=shade(cor, 0.5))
    path = os.path.join(GUI_DIR, f"{nome}.png")
    img.save(path)
    print("Icone HUD criado:", path)


# --- Comida ---
make_food_icon("carne_apodrecida_processada", (110, 90, 60), formato="carne")
make_food_icon("mre_militar", (90, 100, 70), formato="embalagem")
make_food_icon("enlatados", (150, 150, 140), formato="lata")
make_food_icon("barra_energetica", (170, 120, 60), formato="barra")

# --- Agua ---
make_water_icon("agua_filtrada", (90, 180, 220))
make_water_icon("agua_contaminada", (110, 130, 60))

for nome in ["carne_apodrecida_processada", "mre_militar", "enlatados", "barra_energetica",
             "agua_filtrada", "agua_contaminada"]:
    make_item_model(nome)

# --- HUD de sede ---
make_hud_icon("thirst_full", (60, 140, 220))
make_hud_icon("thirst_empty", (60, 140, 220), vazio=True)

print("OK - modulo 3: texturas, modelos e icones de HUD gerados.")
