import json
import os

ROOT = "/home/claude/zombieapoc/src/main/resources/data/zombieapoc"
CONFIGURED_DIR = os.path.join(ROOT, "worldgen/configured_feature")
PLACED_DIR = os.path.join(ROOT, "worldgen/placed_feature")
BIOME_MOD_DIR = os.path.join(ROOT, "forge/biome_modifier")

# nome_feature -> chance (menor = mais comum)
ESTRUTURAS = {
    "casa_abandonada": 30,
    "predio_destruido": 40,
    "hospital_abandonado": 90,
    "delegacia_abandonada": 70,
    "supermercado_abandonado": 60,
    "posto_gasolina": 50,
    "base_militar": 150,
    "veiculo_abandonado": 20,
}

for nome, chance in ESTRUTURAS.items():
    configured = {"type": f"zombieapoc:{nome}", "config": {}}
    with open(os.path.join(CONFIGURED_DIR, f"{nome}.json"), "w", encoding="utf-8") as f:
        json.dump(configured, f, indent=2)

    placed = {
        "feature": f"zombieapoc:{nome}",
        "placement": [
            {"type": "minecraft:rarity_filter", "chance": chance},
            {"type": "minecraft:in_square"},
            {"type": "minecraft:heightmap", "heightmap": "WORLD_SURFACE_WG"},
            {"type": "minecraft:biome"}
        ]
    }
    with open(os.path.join(PLACED_DIR, f"{nome}.json"), "w", encoding="utf-8") as f:
        json.dump(placed, f, indent=2)

    print("Criado configured+placed:", nome)

biome_modifier = {
    "type": "forge:add_features",
    "biomes": "#minecraft:is_overworld",
    "features": [f"zombieapoc:{nome}" for nome in ESTRUTURAS.keys()],
    "step": "surface_structures"
}
with open(os.path.join(BIOME_MOD_DIR, "add_abandoned_structures.json"), "w", encoding="utf-8") as f:
    json.dump(biome_modifier, f, indent=2)
print("Criado biome modifier: add_abandoned_structures.json")
