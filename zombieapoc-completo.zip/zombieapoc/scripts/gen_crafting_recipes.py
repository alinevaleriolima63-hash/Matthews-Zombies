import json
import os

BASE = "/home/claude/zombieapoc/src/main/resources/data/zombieapoc/recipes"
os.makedirs(BASE, exist_ok=True)

MOD = "zombieapoc"


def mc(nome):
    return f"minecraft:{nome}"


def mod(nome):
    return f"{MOD}:{nome}"


def salvar(nome_arquivo, dados):
    path = os.path.join(BASE, f"{nome_arquivo}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=2)
    print("Criado:", path)


def shapeless(nome_arquivo, ingredientes, resultado_item, count=1):
    salvar(nome_arquivo, {
        "type": "minecraft:crafting_shapeless",
        "ingredients": [{"item": i} for i in ingredientes],
        "result": {"item": resultado_item, "count": count}
    })


def shaped(nome_arquivo, pattern, key, resultado_item, count=1):
    salvar(nome_arquivo, {
        "type": "minecraft:crafting_shaped",
        "pattern": pattern,
        "key": {k: {"item": v} for k, v in key.items()},
        "result": {"item": resultado_item, "count": count}
    })


# ---------- ARMAS CORPO A CORPO (shaped, lembram os formatos vanilla) ----------

shaped("receita_katana", [" X ", " X ", " Y "],
       {"X": mc("diamond"), "Y": mc("stick")}, mod("katana"))

shaped("receita_machado", ["XX ", "XY ", " Y "],
       {"X": mc("iron_ingot"), "Y": mc("stick")}, mod("machado"))

shaped("receita_pa_de_trincheira", [" X ", " Y ", " Y "],
       {"X": mc("iron_ingot"), "Y": mc("stick")}, mod("pa_de_trincheira"))

shaped("receita_marreta", ["XXX", " Y ", " Y "],
       {"X": mc("iron_ingot"), "Y": mc("stick")}, mod("marreta"))

# ---------- ARMAS CORPO A CORPO (shapeless, combinacoes simples) ----------

shapeless("receita_faca_de_combate", [mc("iron_ingot"), mc("stick")], mod("faca_de_combate"))
shapeless("receita_bastao_com_pregos",
          [mc("stick"), mc("iron_nugget"), mc("iron_nugget"), mc("iron_nugget")], mod("bastao_com_pregos"))
shapeless("receita_taco_de_baseball",
          [mc("oak_planks"), mc("oak_planks"), mc("oak_planks"), mc("stick")], mod("taco_de_baseball"))
shapeless("receita_motosserra",
          [mc("iron_ingot"), mc("iron_ingot"), mc("stick"), mod("bateria"), mod("peca_eletronica")],
          mod("motosserra"))

# ---------- ARMAS DE FOGO ----------

shapeless("receita_pistola",
          [mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"), mod("peca_eletronica")], mod("pistola"))
shapeless("receita_rifle",
          [mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"),
           mc("stick"), mod("peca_eletronica")], mod("rifle"))
shapeless("receita_shotgun",
          [mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"), mc("iron_ingot"), mc("stick"),
           mod("peca_eletronica")], mod("shotgun"))
shapeless("receita_granada",
          [mc("iron_ingot"), mc("gunpowder"), mod("peca_eletronica")], mod("granada"))

# ---------- MUNICAO ----------

shapeless("receita_municao_pistola", [mc("iron_nugget"), mc("gunpowder")], mod("municao_pistola"), count=4)
shapeless("receita_municao_rifle", [mc("iron_ingot"), mc("gunpowder")], mod("municao_rifle"), count=4)
shapeless("receita_cartucho_espingarda",
          [mc("paper"), mc("gunpowder"), mc("iron_nugget")], mod("cartucho_espingarda"), count=4)

# Receita "upgrade": producao em lote usando bateria + peca eletronica
shapeless("receita_municao_rifle_lote",
          [mod("bateria"), mod("peca_eletronica"), mc("iron_ingot"), mc("iron_ingot")],
          mod("municao_rifle"), count=8)

# ---------- SOBREVIVENCIA ----------

shapeless("receita_kit_medico", [mc("paper"), mc("paper"), mc("sugar")], mod("kit_medico"))
shapeless("receita_combustivel", [mc("coal"), mc("coal"), mc("coal"), mc("redstone")], mod("combustivel"))

print("OK - modulo 6: todas as receitas geradas.")
