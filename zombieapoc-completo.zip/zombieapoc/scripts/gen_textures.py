import os
import random
from PIL import Image, ImageDraw

random.seed(42)

BASE = "/home/claude/zombieapoc/src/main/resources/assets/zombieapoc"
ENTITY_DIR = os.path.join(BASE, "textures/entity/zombie")
ITEM_DIR = os.path.join(BASE, "textures/item")
MODEL_DIR = os.path.join(BASE, "models/item")
os.makedirs(ENTITY_DIR, exist_ok=True)
os.makedirs(ITEM_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

SIZE = 64


def clamp(v):
    return max(0, min(255, int(v)))


def make_entity_skin(nome, base_color, speckle_color, speckle_amount=0.08):
    """Gera uma skin 64x64 TOTALMENTE OPACA (formato igual ao skin
    vanilla de zumbi/player) preenchendo o canvas inteiro com uma cor
    base + ruido, para nao deixar nenhuma parte do modelo transparente
    ou com UV 'furado' - isso e o que evita zumbi com pedacos
    invisiveis/pretos no jogo."""
    img = Image.new("RGBA", (SIZE, SIZE), (*base_color, 255))
    px = img.load()
    for y in range(SIZE):
        for x in range(SIZE):
            if random.random() < speckle_amount:
                r, g, b = speckle_color
                jitter = random.randint(-10, 10)
                px[x, y] = (clamp(r + jitter), clamp(g + jitter), clamp(b + jitter), 255)
    path = os.path.join(ENTITY_DIR, f"{nome}.png")
    img.save(path)
    print("Skin criada:", path)


def make_item_icon(nome, shape_color, shape="blob"):
    """Icone 64x64 com fundo TRANSPARENTE (alpha 0) e o desenho do
    item com alpha 255 (transparencia correta, sem 'halo' cinza)."""
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    r, g, b = shape_color
    escuro = (clamp(r * 0.6), clamp(g * 0.6), clamp(b * 0.6), 255)
    claro = (clamp(r * 1.25), clamp(g * 1.25), clamp(b * 1.25), 255)

    if shape == "blob":
        draw.ellipse([14, 18, 50, 48], fill=(r, g, b, 255), outline=escuro, width=3)
        draw.ellipse([20, 22, 32, 32], fill=claro)
    elif shape == "meat":
        draw.rounded_rectangle([16, 14, 48, 50], radius=10, fill=(r, g, b, 255), outline=escuro, width=3)
        for i in range(4):
            y = 20 + i * 8
            draw.line([18, y, 46, y], fill=escuro, width=2)
    elif shape == "core":
        draw.polygon([(32, 10), (52, 32), (32, 54), (12, 32)], fill=(r, g, b, 255), outline=escuro)
        draw.polygon([(32, 18), (44, 32), (32, 46), (20, 32)], fill=claro)

    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_item_model(nome, parent="item/generated"):
    """Modelo JSON do item. Usar os parents vanilla (item/generated
    para icones planos) garante posicao/rotacao/escala corretas em
    maos, inventario e chao SEM precisar escrever 'display transforms'
    na mao - a Mojang ja testou esses valores."""
    content = (
        "{\n"
        f'  "parent": "{parent}",\n'
        '  "textures": {\n'
        f'    "layer0": "zombieapoc:item/{nome}"\n'
        "  }\n"
        "}\n"
    )
    path = os.path.join(MODEL_DIR, f"{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Modelo criado:", path)


# --- Skins dos 5 zumbis (64x64, iguais ao formato vanilla) ---
make_entity_skin("normal", (94, 130, 82), (60, 90, 55))
make_entity_skin("armado", (85, 120, 78), (70, 70, 65))
make_entity_skin("queimado", (46, 42, 40), (90, 40, 20), speckle_amount=0.12)
make_entity_skin("mutante", (70, 110, 70), (40, 70, 100), speckle_amount=0.10)
make_entity_skin("necromante", (55, 35, 70), (20, 15, 30), speckle_amount=0.06)

# --- Icones dos itens do modulo 1 ---
make_item_icon("parte_zumbi", (120, 150, 100), shape="meat")
make_item_icon("carne_zumbi_queimada", (60, 45, 35), shape="meat")
make_item_icon("nucleo_necromante", (140, 60, 200), shape="core")

for nome in ["parte_zumbi", "carne_zumbi_queimada", "nucleo_necromante"]:
    make_item_model(nome)

print("OK - todas as texturas e modelos do modulo 1 foram gerados.")
