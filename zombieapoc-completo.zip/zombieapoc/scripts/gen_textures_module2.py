import os
from PIL import Image, ImageDraw

BASE = "/home/claude/zombieapoc/src/main/resources/assets/zombieapoc"
ITEM_DIR = os.path.join(BASE, "textures/item")
MODEL_DIR = os.path.join(BASE, "models/item")
os.makedirs(ITEM_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

SIZE = 64


def clamp(v):
    return max(0, min(255, int(v)))


def shade(color, factor):
    r, g, b = color
    return (clamp(r * factor), clamp(g * factor), clamp(b * factor), 255)


def make_blade_icon(nome, blade_color, handle_color=(90, 60, 40), comprido=False):
    """Arma corpo a corpo: lamina na diagonal + cabo. comprido=True
    deixa a lamina maior (katana/machado/marreta/motosserra)."""
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    if comprido:
        lamina = [(46, 6), (58, 18), (26, 50), (14, 38)]
        cabo = [(20, 42), (30, 52), (18, 62), (10, 54)]
    else:
        lamina = [(44, 10), (52, 18), (28, 46), (20, 38)]
        cabo = [(22, 40), (30, 48), (16, 60), (10, 54)]

    draw.polygon(lamina, fill=(*blade_color, 255), outline=shade(blade_color, 0.6))
    draw.polygon(cabo, fill=(*handle_color, 255), outline=shade(handle_color, 0.6))
    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_gun_icon(nome, body_color, comprimento=34):
    """Silhueta simples de arma de fogo (cano + cabo + gatilho)."""
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    escuro = shade(body_color, 0.6)

    y_cano = 26
    draw.rounded_rectangle([12, y_cano, 12 + comprimento, y_cano + 8], radius=3,
                           fill=(*body_color, 255), outline=escuro, width=2)
    # cabo (grip)
    draw.polygon([(18, y_cano + 8), (26, y_cano + 8), (22, 54), (14, 50)],
                 fill=(*body_color, 255), outline=escuro)
    # gatilho
    draw.ellipse([20, y_cano + 8, 27, y_cano + 15], outline=escuro, width=2)

    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_ammo_icon(nome, color, formato="bala"):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    escuro = shade(color, 0.6)
    claro = shade(color, 1.3)

    if formato == "bala":
        draw.rounded_rectangle([26, 14, 38, 40], radius=4, fill=(*color, 255), outline=escuro, width=2)
        draw.polygon([(26, 14), (38, 14), (32, 4)], fill=(*claro[:3], 255))
    elif formato == "cartucho":
        draw.rounded_rectangle([22, 10, 42, 44], radius=6, fill=(*color, 255), outline=escuro, width=2)
        draw.rectangle([22, 34, 42, 44], fill=(*escuro[:3], 255))

    path = os.path.join(ITEM_DIR, f"{nome}.png")
    img.save(path)
    print("Icone criado:", path)


def make_item_model(nome, parent):
    content = (
        "{\n"
        f'  "parent": "{parent}",\n'
        '  "textures": {\n'
        f'    "layer0": "zombieapoc:item/{nome}"\n'
        "  }\n"
        "}\n"
    )
    path = os.path.join(MODEL_DIR, f"{nome}.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Modelo criado:", path)


# --- Armas corpo a corpo (parent handheld = posicao/rotacao corretas na mao) ---
make_blade_icon("faca_de_combate", (200, 200, 210))
make_blade_icon("katana", (220, 220, 230), comprido=True)
make_blade_icon("bastao_com_pregos", (120, 85, 55))
make_blade_icon("taco_de_baseball", (170, 130, 80))
make_blade_icon("marreta", (110, 110, 115), handle_color=(80, 55, 35), comprido=True)
make_blade_icon("machado", (150, 150, 160), handle_color=(100, 70, 45), comprido=True)
make_blade_icon("pa_de_trincheira", (140, 140, 150), handle_color=(90, 62, 40))
make_blade_icon("motosserra", (200, 60, 40), handle_color=(40, 40, 40), comprido=True)

# --- Armas de fogo (parent handheld tambem) ---
make_gun_icon("pistola", (70, 70, 75), comprimento=20)
make_gun_icon("rifle", (60, 55, 45), comprimento=40)
make_gun_icon("shotgun", (90, 65, 40), comprimento=36)

# --- Granada e municao (parent generated - itens pequenos, nao "handheld") ---
img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)
draw.ellipse([18, 16, 46, 46], fill=(60, 90, 60, 255), outline=(30, 45, 30, 255), width=3)
draw.rectangle([28, 8, 36, 18], fill=(120, 120, 120, 255))
img.save(os.path.join(ITEM_DIR, "granada.png"))
print("Icone criado: granada.png")

make_ammo_icon("municao_pistola", (200, 170, 60), formato="bala")
make_ammo_icon("municao_rifle", (180, 150, 50), formato="bala")
make_ammo_icon("cartucho_espingarda", (190, 60, 40), formato="cartucho")

# --- Modelos JSON ---
for nome in ["faca_de_combate", "katana", "bastao_com_pregos", "taco_de_baseball",
             "marreta", "machado", "pa_de_trincheira", "motosserra",
             "pistola", "rifle", "shotgun"]:
    make_item_model(nome, "item/handheld")

for nome in ["granada", "municao_pistola", "municao_rifle", "cartucho_espingarda"]:
    make_item_model(nome, "item/generated")

print("OK - modulo 2: texturas e modelos gerados.")
