import os
from PIL import Image

ENTITY_DIR = "/home/claude/zombieapoc/src/main/resources/assets/zombieapoc/textures/entity/zombie"

VARIANTES = ["normal", "armado", "queimado", "mutante", "necromante"]

# Posicao dos olhos na face frontal da cabeca, no layout padrao de
# skin do Minecraft (a face frontal da cabeca ocupa o retangulo
# x:[8,16) y:[8,16) num skin 64x64). Olho esquerdo/direito na altura
# y=11, valores classicos usados desde a skin padrao do Steve.
OLHO_ESQUERDO = [(9, 11), (10, 11)]
OLHO_DIREITO = [(13, 11), (14, 11)]

VERMELHO = (230, 20, 20, 255)
VERMELHO_BRILHO = (255, 90, 60, 255)


def gerar_noturna(nome):
    caminho_dia = os.path.join(ENTITY_DIR, f"{nome}.png")
    img = Image.open(caminho_dia).convert("RGBA")
    px = img.load()

    for (x, y) in OLHO_ESQUERDO + OLHO_DIREITO:
        px[x, y] = VERMELHO
    # pixel de "brilho" no canto de cada olho, pra parecer que emite luz
    px[9, 10] = VERMELHO_BRILHO
    px[14, 10] = VERMELHO_BRILHO

    caminho_noite = os.path.join(ENTITY_DIR, f"{nome}_noite.png")
    img.save(caminho_noite)
    print("Textura noturna criada:", caminho_noite)


for variante in VARIANTES:
    gerar_noturna(variante)

print("OK - texturas noturnas geradas para os 5 zumbis.")
