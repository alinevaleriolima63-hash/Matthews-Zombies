# Zombie Apocalypse - Mod Forge (1.20.1)

## Status: MOD COMPLETO (Módulos 1-6) + Ajuste: zumbis à noite

**Novo:** todos os 5 tipos de zumbi agora ficam com **olhos vermelhos
e 35% mais rápidos** enquanto for noite no mundo (mesmo intervalo de
tempo que o Minecraft usa pra decidir se hostis podem spawnar na
superfície - `ApocalypseTimeUtil.ehNoite()`). O bônus de velocidade é
um `AttributeModifier` aplicado/removido automaticamente a cada
segundo (checagem barata, não roda em todo tick); a troca de textura
acontece no renderer, sem custo extra de servidor. Os "olhos" são só
alguns pixels vermelhos na posição padrão do rosto do skin (minhas
texturas são simples demais pra ter rosto desenhado de verdade) -
funcional, mas simples; fica melhor ainda quando trocar pelas
texturas reais.


## Módulo 6 (novo e final): Crafting

19 receitas no total (`data/zombieapoc/recipes/`):
- 4 armas corpo a corpo com formato (katana, machado, pá, marreta -
  desenho parecido com as ferramentas vanilla)
- 4 armas corpo a corpo simples (faca, bastão, taco, motosserra)
- 4 armas de fogo (pistola, rifle, shotgun, granada) - todas usam
  Peça Eletrônica, então dependem de saquear estruturas primeiro
- 3 receitas de munição + 1 receita "de lote" usando bateria + peça
  eletrônica (o "upgrade" pedido: fabricação em lote assistida por
  eletrônica, 8 munições de uma vez em vez de 4)
- Kit Médico (papel + açúcar) e Combustível (carvão + redstone)
- (Água Filtrada a partir de Água Contaminada + Carvão já existia
  desde o módulo 3)

**Bug real encontrado e corrigido nesta revisão:** as 4 receitas com
formato usavam `_` como espaço vazio no pattern. O Minecraft exige
espaço literal `" "` pra célula vazia (`_` sem entrada no `key` dá
erro "symbol not defined"). Corrigido antes de empacotar.

Validei a sintaxe dos **80 arquivos JSON do projeto inteiro** (não só
os novos) com um parser JSON - 0 erros de sintaxe. Isso não garante
que o Minecraft vai aceitar o *conteúdo* (schema semântico), mas
elimina uma classe inteira de erros bobos.

## Resumo Módulos 1-5 - sem mudanças, ver histórico

## IMPORTANTE - leia antes de abrir no seu PC

1. **Não compilei/testei este projeto de verdade** (sem internet
   neste ambiente, do início ao fim). Revisei manualmente cada
   import/registry/JSON, e corrigi vários bugs reais ao longo do
   caminho (lista completa abaixo), mas só confirma 100% compilando
   no seu PC.
2. IntelliJ IDEA + JDK 17, importar como projeto Gradle. Primeira
   sincronização **precisa de internet** (baixa Forge/Minecraft).
3. `./gradlew genIntellijRuns` → run "Minecraft Client".
4. Texturas são placeholders gerados por código (sem internet aqui
   pra baixar arte de terceiros). Troque por texturas reais depois,
   mesma resolução e mesmo nome de arquivo.
5. Pontos marcados com `NOTA:` no código são os de MAIOR risco de não
   compilar de primeira, por dependerem de partes da API do Forge que
   variam entre builds 1.20.1 (capabilities, overlay de HUD, fuel
   event, raytrace de arma). Se algo quebrar, comece por eles.

## Bugs reais encontrados e corrigidos durante o desenvolvimento
(fica aqui de registro, pra você saber que a revisão foi de verdade)
- Import de `@Nullable` errado (org.jetbrains em vez de javax.annotation)
- Pasta `loot_table` no lugar de `loot_tables` (formato 1.20.1 é plural)
- Referência a método inexistente (`getApocalypseType()`) na goal do necromante
- 4 receitas de crafting com `_` em vez de espaço `" "` no pattern

## Estrutura de pacotes (final)

```
com.apocalipse.zombieapoc
├── ZombieApocMod
├── registry     (ModItems, ModEntities, ModSounds, ModCreativeTab,
│                 ModFuelHandler, ModFeatures)
├── entity       (zumbis, goals de IA, GrenadeEntity)
│   └── client   (renderer do zumbi)
├── item         (armas, comida, agua, kit medico)
├── capability   (sistema de sede)
├── network      (canal de rede + pacote de sincronizacao de sede)
├── client       (eventos/overlays de renderizacao)
└── worldgen     (AbandonedBuildingFeature, WreckedVehicleFeature)
```

## O que este mod entrega vs. o pedido original
✅ 5 tipos de zumbi com IA/atributos/loot próprios
✅ 8 armas corpo a corpo + 4 de fogo (carregador/recarga de verdade)
✅ Comida, água, sistema de sede completo com HUD
✅ Kit médico, combustível, bateria, peça eletrônica
✅ 8 estruturas espalhadas pelo mapa inteiro + loot por tipo
✅ 19 receitas de crafting
⚠️ Geração de mundo é "prédios variados espalhados", não "cidades
   conectadas por ruas" (isso exigiria arquivos .nbt feitos dentro do
   jogo - ver Módulo 5 acima)
⚠️ Texturas são placeholders simples gerados por código, não arte
   baixada da internet (não tenho acesso a internet neste ambiente)
⚠️ Nada disso foi compilado/testado de verdade (mesma limitação)





